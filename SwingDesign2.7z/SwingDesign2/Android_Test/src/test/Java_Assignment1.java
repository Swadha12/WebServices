package test;

import java.lang.reflect.Array;

public class Java_Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  // int[] ar= new int[10];
 int[]  ar={1,1,2,2,2,3,3,4,5,9,8};
    for (int i=0;i<10;i++){
    	
    	if(ar[i]==ar[i+1]){
    	System.out.println(ar[i]);	
    	}
    
	}
    System.out.println("reverse of number is--");
for(int j=10;j>0;j--){
	
	System.out.println(ar[j]);
}
	
for(int k=0;k<10;k++){
	
}

	}	
}