package test;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.*;

public class PDFReader {

	

			public static void main(String arg[])throws Exception
			{
				Document document=new Document(); 
			PdfWriter.getInstance(document,new FileOutputStream("hello.pdf"));
			document.open();
			document.add(new Paragraph("Hello world this is my first PDF")); 
			document.close(); 
			}
		}
	


