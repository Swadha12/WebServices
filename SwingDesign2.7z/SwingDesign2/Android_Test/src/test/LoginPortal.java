package test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Choice;
import javax.swing.JTextArea;

public class LoginPortal<TypeOfFile, lblFileName> {

	private JFrame frame;
	private JTextField username;
	private JPasswordField password;
	JTextArea txtrTttetrr;
	final JFileChooser fc=new  JFileChooser();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPortal window = new LoginPortal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoginPortal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws FileNotFoundException 
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(21, 70, 84, 14);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(21, 117, 84, 14);
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.getContentPane().add(lblPassword);
		
		username = new JTextField();
		username.setBounds(115, 69, 141, 20);
		frame.getContentPane().add(username);
		username.setColumns(10);
		

		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(21, 196, 89, 23);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				username.setText(null);
				password.setText(null);
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 14));
		frame.getContentPane().add(btnReset);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(120, 196, 89, 23);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String uname=username.getText();
				String psd=password.getText();
				if(uname.equals("name") && psd.equals("password")){
					JOptionPane.showMessageDialog(frame, "You have successfully looged in..");
					
				}else{
					JOptionPane.showMessageDialog(frame, "Incorrect username or password..");
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 14));
		frame.getContentPane().add(btnLogin);
		
		password = new JPasswordField();
		password.setBounds(115, 116, 141, 20);
		frame.getContentPane().add(password);
		
		JTextArea txtrTttetrr = new JTextArea();
		txtrTttetrr.setBounds(266, 47, 158, 133);
		frame.getContentPane().add(txtrTttetrr);
		OpenFile of= new OpenFile();
		JButton btnNewButton = new JButton("Browse");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			try{
					of.PickMe();						
				}catch(Exception e){
					e.printStackTrace();
				}
			    txtrTttetrr.setText(of.sb.toString());
				txtrTttetrr.setText(toHex(of.sb.toString()));
				//txtrTttetrr.setText(of.sb.toString());
				try{
					Document document=new Document(); 
				PdfWriter.getInstance(document,new FileOutputStream("C:\\Users\\stripathi\\Desktop\\CSVtoPDFConvert.pdf"));
				document.open();
				document.add(new Paragraph(of.sb.toString())); 
				document.close(); 
				}
				catch(Exception e){
					e.getStackTrace();
				}
			}
		});
		btnNewButton.setBounds(294, 198, 89, 23);
		frame.getContentPane().add(btnNewButton);
	}
	public static String toHex(String args){
	    //System.out.println("Hexadecimal value of name is-" +String.format("%x", new BigInteger(args.getBytes())));
		return String.format("%x", new BigInteger(args.getBytes()));
		}
}
