package com.UtilityFiles;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class KillExistingDriver {
    
    private static final String TASKLIST = "tasklist";
    private static final String KILL = "taskkill /F /IM ";
    
public static void killService(String ServiceName){
    try{
    Process p = Runtime.getRuntime().exec(TASKLIST);
    BufferedReader reader = new BufferedReader(new InputStreamReader(
    p.getInputStream()));
    String line;
    while ((line = reader.readLine()) != null) {

    System.out.println(line);
      if (line.contains(ServiceName) || line.contains("explorer.exe")) {
    	  System.out.println(ServiceName);
             Runtime.getRuntime().exec(KILL + ServiceName);
      }
    }

}catch(Exception e){
    e.printStackTrace();
}
}
}

