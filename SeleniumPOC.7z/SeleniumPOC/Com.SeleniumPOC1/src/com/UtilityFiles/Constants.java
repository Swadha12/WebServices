package com.UtilityFiles;

public class Constants {
	 public static final String BRW_NAME_FF = "firefox";
	 public static final String BRW_NAME_IE = "ie";
	 public static final String URL_Briova = "https://uatpatient.briovarx.com/";
	 public static final String URL_IPlan = "http://10.3.65.141/IplanE2QA/Pages/IplanLogin.aspx";
	 public static final String URL_Prime="http://devcsa.primeclerk.com/CM/Home-Login";
	 public static final String EXL_PATH = "./testdata/testdata.xlsx";
	 public static final String ID_Briova="ssanka@galaxe.com";
	 public static final String PWD_Briova="Test@123";
	 public static final String ID_Prime="glxinput1";
	 public static final String PWD_Prime="Galaxy@123";
	 public static final String file_Path="D:\\FrameWork\\AddDocumenttest.pdf";
	 public static final String docketNumber_Prime="85698";
	 public static final String caseName_Prime="PrimePOC (16-16744)";
	 
}
