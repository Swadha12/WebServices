package com.UtilityFiles;

public class FPath 
{
       public static final String DRIVE_PATH             ="D://FrameWork";
       public static final String DRIVE_PATH2            ="D:/FrameWork";       
       public static final String PROP_FILE              ="D://FrameWork//Propertise//prop.properties";      
       public static final String ACTUAL_TABLE           =DRIVE_PATH+"\\ActualSheet.xls";
       public static final String ACTUAL_SHEET           =DRIVE_PATH+"\\ActualSheet.xls";
       public static final String RESULTS                =DRIVE_PATH2+"/Results/Result_";
       public static final String LOGS                   =DRIVE_PATH2+"/Logs/Log_";
       public static final String SCREENSHOT             =DRIVE_PATH2+"/ScreenShots/ScreenShot_";
       public static final String RESULT_TEMPLATE        =DRIVE_PATH+"\\Templates\\Result_Template.xlsx";
       public static final String TESTSTEP_TEMPLATE      =DRIVE_PATH2+"/Templates/TestStep_Template.xlsx";
       public static final String SCREENSHOT_FOLDER      =DRIVE_PATH+"\\ScreenShots ";
       public static final String SCREENSHOT_EXE         =DRIVE_PATH+"\\ScreenShots\\Screenshot.exe  ";
       public static final String CONFIGURATION          =DRIVE_PATH+"\\Configuration.xlsx";
       public static final String TESTDATA               ="D://FrameWork//Test_Data.xlsx";
       public static final String ExtentReport           =DRIVE_PATH2+"/ExtentReports/ExtentReports_";
       
       
}

