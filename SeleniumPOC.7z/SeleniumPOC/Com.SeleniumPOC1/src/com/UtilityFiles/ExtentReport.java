package com.UtilityFiles;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;

import com.DriverScript.MasterScript;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReport {
	
	public static int counter;
    public static int ScreenShotCounter=1;
	
	public static ExtentTest test;
	public static ExtentReports extent;
    public static ExtentReport classAInstance = new ExtentReport();
	public void startReport(String mypath){
		 mypath= ""+MasterScript.ExtentReportPath+"/Briova.HTML";
		try{
		extent = new ExtentReports(mypath,false);
		}catch(Exception e){
			System.out.println("Report already Created Moving on to the next Step");
		}
		String extnPath="D:\\FrameWork\\config.xml";
		extent.loadConfig(new File(extnPath));
		//extent.config().reportName("D:\\FrameWork\\Logo\\OptumLogo.png");
		//extent = new ExtentReports("D:\\FrameWork\\ExtentReports\\Briova.HTML",true);
	//	test = extent.startTest(CalssName,"Test Report");
	}
	
	public void StartTest(String CalssName){
		test = extent.startTest(CalssName,"Test Report");
	}
	
	public void logReport(String Status, String Steps, String Actual) throws IOException, AWTException{
		if(Status.equalsIgnoreCase("Pass")){
		test.log(LogStatus.PASS,Steps,Actual);
		}
		else {
		test.log(LogStatus.FAIL,Steps,Actual);
		String filepath = GenericLibrary.screenShotLink;
		//String filepath=CommonFunctions.screenshot(CommonUtils.drv, "demo");
		test.log(LogStatus.FAIL,"Fail","Test case fail Screen shot " +test.addScreenCapture(filepath));
		//test.addScreenCapture(filepath);
		ScreenShotCounter=ScreenShotCounter+1;	
		}
	}
	public void endReport(){
		extent.endTest(test);
		extent.flush();
		//extent.flush();
	}

}
