package com.UtilityFiles;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.DriverScript.MasterScript;



public class CommonUtils {
	
	public static WebDriver drv=null;
	
	public WebDriver getDriverObject() throws InterruptedException
	{	
	
	  String brwName = MasterScript.Browser;
	  String URLName= MasterScript.URL;
	
	  switch(brwName)
	  {
	  case "ie":
		 KillExistingDriver.killService("IEDriverServer.exe");
		 String path = "D:\\Automation\\Selenium\\Drivers\\IEDriverServer.exe"; 
		 System.setProperty("webdriver.ie.driver",path);		
		 DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		 capabilities.setCapability("requireWindowFocus", true);
		 capabilities.setCapability("nativeEvents",false);
		 capabilities.setCapability("ignoreZoomSetting", true);		 
		 drv = new InternetExplorerDriver(capabilities);
		 break;
		 
	  case "Edge":
		 KillExistingDriver.killService("MicrosoftWebDriver.exe");
		// DesiredCapabilities capabilities1 = DesiredCapabilities.edge();
		 String path2 = "D:\\Automation\\Selenium\\Drivers\\MicrosoftWebDriver.exe";
		 System.setProperty("webdriver.edge.driver",path2);
		 drv = new EdgeDriver();
		 System.out.println("Edge");
		 break;
	  case "firefox":
		 KillExistingDriver.killService("geckodriver.exe");
		 System.setProperty("webdriver.gecko.driver", "D:\\Automation\\Selenium\\Drivers\\geckodriver.exe");
	     drv = new FirefoxDriver();
	     break;
	  case "chrome":
		String path1 = "./executables/chromedriver.exe";  
		System.setProperty("webdriver.chrome.driver",path1);
		drv = new ChromeDriver();
		break;
	   default:
		   System.out.println("Invalid Browser");
	  }
	   
	  drv.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	  Thread.sleep(3000);
	  drv.manage().window().maximize();
	  Thread.sleep(3000);
	  drv.get(URLName);
	  Thread.sleep(3000);	  
	  return drv; 
	}

}
