package com.Specific_Methods;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.DriverScript.MasterScript;
import com.Pom_IPlan_NBA.IplanCategoryPage;
import com.Pom_IPlan_NBA.IplanCopyDetailsPage;
import com.Pom_IPlan_NBA.IplanCopyFromSourcePage;
import com.Pom_IPlan_NBA.IplanCopyFromSrcEditPlanPage;
import com.Pom_IPlan_NBA.IplanLoginPage;
import com.Pom_IPlan_NBA.IplanMenuOptionPage;
import com.UtilityFiles.ExtentReport;
import com.UtilityFiles.GenericLibrary;
import com.prop.PropData;

public class TestCase_Specific_Methods_IPlan_NBA {public ArrayList<Boolean> statusList=new ArrayList<Boolean>();
Boolean Sts = false;
public static String StepSts = null;
public static String Expected = null;
public static String Actual = null;

/*
================================================================================================ 
 -Method Name: selectDropDown
 -Description: All dropdown selection methods presents in different pages are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean selectDropDown(WebDriver drv, String PageName, String ElementName)
 
{
	boolean result=false;
	String DropDownValue = null;

		switch(PageName) {
	
		case "IplanLoginPage" :
			
			IplanLoginPage loginpage = new IplanLoginPage(drv);
			DropDownValue= PropData.loadProp().getProperty("IplanLoginPage_LogInProfile");
			result = loginpage.selectProfile(DropDownValue);
			break;
	
		case "IplanCategoryPage" :
	
			break;
			
		case "IplanCopyFromSourcePage" :
	
			IplanCopyFromSourcePage CopyfrmSrc = new IplanCopyFromSourcePage(drv);
			try{				
			if(ElementName.equalsIgnoreCase("Select Season")){
			DropDownValue= PropData.loadProp().getProperty("IplanCopyFromSourcePage_Season");	
			result = CopyfrmSrc.selectSeason(DropDownValue);
			
			}else if (ElementName.equalsIgnoreCase("Select Plan")){
			DropDownValue= PropData.loadProp().getProperty("IplanCopyFromSourcePage_Plan");	
			result = CopyfrmSrc.slelectPlan(DropDownValue);
			}			
	        }
			catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}
			break;
			
		case "IplanCopyFromSrcEditPlanPage" :
	
			IplanCopyFromSrcEditPlanPage CopyfrmEditSrc = new IplanCopyFromSrcEditPlanPage(drv);
			try{				
			if(ElementName.equalsIgnoreCase("Select EditedSeason")){
			DropDownValue= PropData.loadProp().getProperty("IplanCopyFromSrcEditPlanPage_SeasonName");	
			result = CopyfrmEditSrc.iplanCopyEditSeason(DropDownValue);
			}			
	        }
			catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}
			break;
	
		}
	
	try{
		String Steps = "Select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
		if(result==false)
		{						
			String Expected  = "User should be able to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
			String Actual = "Unable to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page is NOT successfull");
			result = false;				
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);				
							
		}else
		{
			String Expected = "User should be able to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
			String Actual = "Able to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";		
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}



/*
================================================================================================ 
 -Method Name: clickButton
 -Description: All Button click methods presents in different pages are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By:
 ================================================================================================
 */
public boolean clickButton(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);					
		try{
		if(ElementName.equalsIgnoreCase("LogIn")){
		result = loginpage.clickLoginBtn();
		}
		else if(ElementName.equalsIgnoreCase("LogOut")){
		result = loginpage.clickLogoutBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "IplanCategoryPage" :
		
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Add Category")){
		result = CatPage.clickAddNewCatBtn();
		}					
		else if(ElementName.equalsIgnoreCase("Save Category")){
		result =CatPage.clickSaveCateBtn();						
		}
		else if (ElementName.equalsIgnoreCase("Search Category")){
		result =CatPage.clickSearcBtton();
		}					
	    else if (ElementName.equalsIgnoreCase("Update Category")){
		result =CatPage.clickUpdateCategoryBtn();
		}					
	    else if (ElementName.equalsIgnoreCase("Update")){
		result =CatPage.clickUpdateBtn();
		}
	    else if (ElementName.equalsIgnoreCase("Delete Category")){
			result =CatPage.clickDeletCatBtn();
			}
		
		
		
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "IplanCopyFromSourcePage" :
		
		IplanCopyFromSourcePage cpyfromsrc = new IplanCopyFromSourcePage(drv);
		try{
		if(ElementName.equalsIgnoreCase("OK")){
		result = cpyfromsrc.clickOkBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "IplanCopyFromSrcEditPlanPage" :
		
		IplanCopyFromSrcEditPlanPage cpyfromeditsrc = new IplanCopyFromSrcEditPlanPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Copy Next")){
		result = cpyfromeditsrc.iplanCopyNextBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "IplanCopyDetailsPage" :
		
		IplanCopyDetailsPage cpyplndetails = new IplanCopyDetailsPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Submit Plan Details")){
		result = cpyplndetails.iplanCopyPlnDtlSubmitBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;		
		

	}

	try{
		
		String Steps = "Click on '"+ElementName+"' Button in '"+PageName+"' Page";
		String Expected = "User Should be able to click on '"+ElementName+"' Button in '"+PageName+"' Page";

		if(result==false)
		{						
			String Actual = "Unable to Click on '"+ElementName+"' Button in '"+PageName+"' Page";
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Click on '"+ElementName+"' Button in '"+PageName+"' Page is NOT successfull");
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			result = false;						
		}else
		{	
			String Actual = "Able to Click on '"+ElementName+"' Button in '"+PageName+"' Page";						
			GenericLibrary.setCellData("Click on '"+ElementName+"' in '"+PageName+"' Page","User Should be able to click on '"+ElementName+"' in '"+PageName+"' Page","Able to Click on '"+ElementName+"' in '"+PageName+"' Page","Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Click on '"+ElementName+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);					
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: check/uncheck Check boxes
 -Description: All Button clickcheck/uncheck Check boxes methods are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By:
 ================================================================================================
 */
public boolean selectCheckBox(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);

		break;
		
	case "IplanCategoryPage" :
		
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);					
		try{
		if(ElementName.equalsIgnoreCase("Uncheck Active Status")){
		result = CatPage.selectChkBoxtToInactive();
		}
		
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;

	}

	try{
		String Steps = null;
		String Expected = null;					
		String[] strArr = ElementName.split(" ");
		{
		if(strArr[0].equalsIgnoreCase("Uncheck")){
		Steps = "Uncheck '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		Expected = "User Should be able to Uncheck '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		
		}else{					
		Steps = "Check '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		Expected = "User Should be able to Check '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		}	
		}
		
		if(result==false)
		{	
			String Actual = "NOT able to "+Expected.replace("User Should be able to", " ")+" ";											
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Click on '"+ElementName+"' in '"+PageName+"' Page is NOT successfull");
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);				
			//ExtentReport.classAInstance.logReport("Fail","Screnshot Below",GenericLibrary.snapShot(Steps+".jpg", MasterScript.ScreenShotPath));
			//String screenpath = TestCase_Specific_Methods.capture(drv, Steps.replace("'", ""));						
			//ExtentReport.classAInstance.logReport("Fail", Steps,Actual,screenpath);
			
			result = false;
		}else
		{
			
			String Actual = "Able to "+Expected.replace("User Should be able to", " ")+" ";
			GenericLibrary.setCellData("Click on '"+ElementName+"' in '"+PageName+"' Page","User Should be able to click on '"+ElementName+"' in '"+PageName+"' Page","Able to Click on '"+ElementName+"' in '"+PageName+"' Page","Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Click on '"+ElementName+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
			
			//String screenpath = TestCase_Specific_Methods.capture(drv, Steps.replace("'", ""));
			//ExtentReport.classAInstance.logReport("Fail", Steps,Actual,screenpath);
			
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: clickLink
 -Description: All click on Link methods present in different pages are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean clickLink(WebDriver drv, String PageName, String ElementName)
{
	boolean result=false;
	switch(PageName) {
	case "IplanLoginPage" :
		IplanLoginPage loginpage = new IplanLoginPage(drv);
		
		break;         
	case "IplanMenuOptionPage" :
		IplanMenuOptionPage CatPage = new IplanMenuOptionPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Manage Category")){
			result = CatPage.clickMangCatLink();	
		}
		else if(ElementName.equalsIgnoreCase("Copy I-Plan")){
			result = CatPage.clickcopyIPlanLink();	
		}
		
		
	   }catch(Exception e){
		Reporter.log("Error " + e.getMessage());
		result = false;
	   }

		break;

	}

	try{
		
		String Steps ="Click on '"+ElementName+"' Link in '"+PageName+"' Page";
		String Expected = "User Should be able to click on '"+ElementName+"' Link in '"+PageName+"' Page";

		if(result==false)
		{
			String Actual = "Unable to Click on '"+ElementName+"' Link in '"+PageName+"' Page";						
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Click on '"+ElementName+"' Link in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			
		}else
		{
			String Actual = "Able to Click on '"+ElementName+"' Link in '"+PageName+"' Page";
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Click on '"+ElementName+"' Link in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: enterText
 -Description: Method to enter text value in text box
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean enterText(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String EnterTextValue = null;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);
					
		break;
		
	case "IplanCategoryPage" :
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("New Category Name")){				
		EnterTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_NewCategoryName");
		result = CatPage.enterNewCatName(EnterTextValue);
		}
		else if(ElementName.equalsIgnoreCase("Existing Category Name")){
		EnterTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_ExistingCategoryName");	
		result = CatPage.enterNewCatName(EnterTextValue);			
		}			
		else if(ElementName.equalsIgnoreCase("Search Category Name")){
		EnterTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_SearchCategoryName");	
		result = CatPage.searchCategoryTxtBox(EnterTextValue);		
		}
		else if(ElementName.equalsIgnoreCase("Category Name Null")){
		EnterTextValue	=  "";	
		result = CatPage.updateCatName(EnterTextValue);		
		}			
		
		}catch(Exception e){
		Reporter.log("Error " + e.getMessage());
		result = false;
	    }

		break;
		
	case "IplanCopyFromSrcEditPlanPage" :
		
		IplanCopyFromSrcEditPlanPage cpfrmsrcedit = new IplanCopyFromSrcEditPlanPage(drv);
		
		try{
			if(ElementName.equalsIgnoreCase("Preferred PlanName")){				
			EnterTextValue	=  PropData.loadProp().getProperty("IplanCopyFromSrcEditPlanPage_PreferredPlanName");
			result = cpfrmsrcedit.enterPreferredPlanName(EnterTextValue);
			}
		 }catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		    }
			break;

	       }

	try{

		String Steps = "Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";
		String Expected = "User Should be able to Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";
		if(result==false)
		{
			String Actual= "Unable to Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";			
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			
		}else
		{
			String Actual= "Able to Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";				
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: verifyText
 -Description: Method to verifyText text value
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean verifyText(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String ExpectedTextValue = null;
	String ActualTextValue = null;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);
					
		break;
		
	case "IplanCategoryPage" :
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Verify Category")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_VerifyCategory");			
			ActualTextValue = CatPage.getCateName();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}else if (ElementName.equalsIgnoreCase("Verify Exisitng Category Error")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_ExistingCategoryError");			
			ActualTextValue = CatPage.getExistCatError();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}else if (ElementName.equalsIgnoreCase("Search Result Record")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_ZeroRecordsMatch");			
			ActualTextValue = CatPage.getCatRecords();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}
						
		}	catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}

		break;
	}
	

	try{
		
		String Steps = "Verify text  '"+ExpectedTextValue+"' of '"+ElementName+"' is present in '"+PageName+"' Page";
		String Expected = "Text '"+ExpectedTextValue+"' should be present in '"+PageName+"' Page";
		String Actual = "Text '"+ActualTextValue+"' is Present in '"+PageName+"' Page";
		
		if(result==false)
		{
							
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Text verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
		}else
		{				
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Text verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is NOT successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	

/*
================================================================================================ 
 -Method Name: verifyCheckBoxStatus
 -Description: Method to verifyText text value
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean verifyCheckBoxStatus(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String ExpectedTextValue = null;
	String ActualTextValue = null;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);
					
		break;
		
	case "IplanCategoryPage" :
		
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Disabled")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_InactiveStatusValue");			
			ActualTextValue = CatPage.getcheckBoxStatusDisabled();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}
						
		}	catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}

		break;
	}
	

	try{
		
		String Steps = "Verify check box status  '"+ExpectedTextValue+"' in '"+PageName+"' Page";
		String Expected = "Check box status should be '"+ExpectedTextValue+"' in '"+PageName+"' Page";
		String Actual = "Check box status is '"+ActualTextValue+"' in '"+PageName+"' Page";
		if(result==false)
		{	
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Check box status verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
		}else
		{
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Check box status verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}

/*
================================================================================================ 
 -Method Name: verifyAlert
 -Description: Method to verifyText text value
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean verifyAlert(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String ExpectedTextValue = null;
	String ActualTextValue = null;
	Alert alert = null;
	
	try{
		alert= drv.switchTo().alert();
		ActualTextValue = alert.getText();
		//Thread.sleep(4000);		
	  }	catch(Exception e){
		Reporter.log("Error " + e.getMessage());
		result = false;
	  }

	switch(PageName) {
	
	case "IplanCategoryPage" :
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Alert Cat_Name_Required")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_VerifyforCatNameNull");	
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}			
		}		
		}	catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		
		try{
			if(ElementName.equalsIgnoreCase("Delete Alert")){				
			    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_DeleteAlert");	
				if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
				result = true;
				}else{
				result = false;
				}			
			}		
			}	catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}
		
		break;
	}
	

	try{
		
		String Steps = "Verify alert text  '"+ExpectedTextValue+"' for '"+ElementName+"' is present in '"+PageName+"' Page";			
		String Expected = "Alert text '"+ActualTextValue+"' should be Present for '"+ElementName+"' in '"+PageName+"' Page";
		String Actual = "Alert text '"+ActualTextValue+"' is Present in '"+PageName+"' Page";			
		
		if(result==false)
		{
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Verification of Alert text '"+ExpectedTextValue+"' for '"+ElementName+"' in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			alert.accept();
			drv.switchTo().defaultContent();
			}else
		    {
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Verification of Alert text '"+ExpectedTextValue+"' for '"+ElementName+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass",Steps,Actual);
			alert.accept();
			drv.switchTo().defaultContent();
			}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	



/*
================================================================================================ */



//take Screen shot----
     
    public static String capture(WebDriver drv,String screenShotName) throws IOException
    {
        TakesScreenshot ts = (TakesScreenshot)drv;
        File source = ts.getScreenshotAs(OutputType.FILE);
        String dest = MasterScript.ScreenShotPath+screenShotName+".png";
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);        
                     
        return dest;
    }





}

