package com.Specific_Methods;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.Pom_BriovaRx.HomePage;
import com.Pom_BriovaRx.IplanCategoryPage;
import com.Pom_BriovaRx.IplanLoginPage;
import com.Pom_BriovaRx.IplanMenuOptionPage;
import com.Pom_BriovaRx.Page_Patient_Information;
import com.Pom_BriovaRx.Page_Patient_Login_Logout;
import com.Pom_BriovaRx.Request_Refill;
import com.Pom_BriovaRx.UpdateMyProfile;
import com.UtilityFiles.ExtentReport;
import com.UtilityFiles.GenericLibrary;


public class TestCase_Specific_Methods_Briova {
	public ArrayList<Boolean> statusList=new ArrayList<Boolean>();
	Boolean Sts = false;
	String StepSts;

	public boolean LoginBriovaRx(WebDriver drv,String uname,String pwd)
	{
	  boolean result=false;	
      try{
        Thread.sleep(4000);
    	Page_Patient_Login_Logout pag1 = new Page_Patient_Login_Logout(drv); 
    	Thread.sleep(4000);
    	pag1.UserID().sendKeys(uname); 
    	Thread.sleep(4000);
    	pag1.Password().sendKeys(pwd);
    	Thread.sleep(4000);
    	pag1.LoginButton().click();
    	Thread.sleep(4000);
    	String title = drv.getTitle();
    	System.out.println(title);
    	if(!title.contains(title))
    	{
    		GenericLibrary.setCellData("Login to BriovaRx Application with valid credentilas","user should be able Login to BriovaRx Application with valid credentilas","Unable Login to BriovaRx Application with valid credentilas","Fail");
            statusList.add(false);
            Sts=false;
    	    Reporter.log("Login Unsuccessfull");
    	    result = false;
    	    ExtentReport.classAInstance.logReport("Fail","Login to BriovaRx Application with valid credentilas","Unable Login to BriovaRx Application with valid credentilas");
    	}else
    	{
    		GenericLibrary.setCellData("Login to BriovaRx Application with valid credentilas","user should be able Login to BriovaRx Application with valid credentilas","Login to BriovaRx Application with valid credentilas successfull","Pass");
            Sts=true;
            statusList.add(true);
            Reporter.log("Login successfull");
            result = true;
            ExtentReport.classAInstance.logReport("Pass","Login to BriovaRx Application with valid credentilas","Login to BriovaRx Application with valid credentilas successfull");
    	}
    	  
      }catch(Exception ex)
      {
    	Reporter.log("Error " + ex.getMessage());  
      }
		
     return result; 
	}

	
public boolean LogoutBriovaRx(WebDriver drv) throws Exception
	{
	  boolean result=false;	
      
    	Page_Patient_Login_Logout pag1 = new Page_Patient_Login_Logout(drv);  
    	
    	
    	try{
    		Thread.sleep(4000);
    	pag1.LogOutbtn().click();
    	Thread.sleep(4000);
    	StepSts = "Object found";
    	}catch(Exception e){
    		Reporter.log("Error " + e.getMessage());  
    		StepSts=null;
    	}
    	if(StepSts==null)
    	{
    		GenericLibrary.setCellData("LogOut From BriovaRx Application","user should be able LogOut From BriovaRx Application","LogOut From BriovaRx Application was unsuccessful","Fail");
            statusList.add(false);
            Sts=false;
    	    Reporter.log("Logout Unsuccessfull");
    	    result = false;
    	    ExtentReport.classAInstance.logReport("Fail","user should be able LogOut From BriovaRx Application","LogOut From BriovaRx Application was unsuccessful");
    	}else
    	{
    		GenericLibrary.setCellData("LogOut From BriovaRx Application","user should be able LogOut From BriovaRx Application","LogOut From BriovaRx Application was unsuccessful","Pass");
            Sts=true;
            statusList.add(true);
            Reporter.log("Logout successfull");
            result = true;
            ExtentReport.classAInstance.logReport("Pass","user should be able LogOut From BriovaRx Application","LogOut From BriovaRx Application was successful");
    	}
		
     return result; 
	}
public boolean SelectProfile1(WebDriver drv)
{
  boolean result=false;	
  try{
	HomePage pag2 = new HomePage(drv);  
	
	WebElement StepSts = pag2.List_Patient("Patient");
	Thread.sleep(4000);
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Select Patient Profile","user should be able to select Patient Profile","Unable to select Patient Profile","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient Profile selection Unsuccessfull");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "Select Patient Profile","Unable to select Patient Profile");
	    
	}else
	{
		GenericLibrary.setCellData("Select Patient Profile","user should be able to select Patient Profile","Patient Profile selection Successful","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient Profile selection successfull");
        result = true;
        ExtentReport.classAInstance.logReport("Pass", "Select Patient Profile","Able to select Patient Profile");
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}
//=================
public boolean SelectProfile(WebDriver drv)
{
  boolean result=false;
  try{
	  Thread.sleep(4000);
	  
      IplanLoginPage pag2 = new IplanLoginPage(drv);      
      WebElement StepSts = pag2.List_Profile("John Ritter (IT Admin)");
      Thread.sleep(4000);
      if(StepSts==null)
      {
        GenericLibrary.setCellData("Select Login Profile","user should be able to select Login Profile","Unable to select Login Profile","Fail");
        statusList.add(false);
        Sts=false;
          Reporter.log("Login Profile selection Unsuccessfull");
          result = false;
      }else
      {
            GenericLibrary.setCellData("Select Login Profile","user should be able to select Login Profile","Login Profile selection Successful","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Login Profile selection successfull");
        result = true;
      }
        
  }catch(Exception ex)
  {
      Reporter.log("Error " + ex.getMessage());  
  }   
return result; 
}

/*---------------------- New method------------------------ */

public boolean enterCatName(WebDriver drv)
{
  boolean result=false;
  try{
	  IplanCategoryPage pag2 = new IplanCategoryPage(drv);
	  
	  try{
          Thread.sleep(4000);
          pag2.CategoryName().click();
          pag2.CategoryName().sendKeys("Test Category");
          
          //System.out.println(st);
          StepSts = "Object found";
          }catch(Exception e){
                Reporter.log("Error " + e.getMessage());  
                StepSts=null;
        }
      if(StepSts==null)
      {
        GenericLibrary.setCellData("Enter Category Name","User should be able to enter Category Name","Unable to Click on Login Button","Fail");
        statusList.add(false);
        Sts=false;
          Reporter.log("Login Button Click Operation is Unsuccessfull");
          result = false;
      }else
      {
            GenericLibrary.setCellData("Click on Login Button","user should be able to Click on Login Button","Login Button Click Operation is Successful","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Login Button Click Operation is successfull");
        result = true;
      }
        
  }catch(Exception ex)
  {
      Reporter.log("Error " + ex.getMessage());  
  }
      
return result; 
}
/*---------------------- New method------------------------ */
public boolean clickManageCatLink(WebDriver drv)
{
  boolean result=false;
  try{
      IplanMenuOptionPage IplanCatpage = new IplanMenuOptionPage(drv);  
              try{
                  Thread.sleep(4000);
                  IplanCatpage.ManageCatLi().click();
                  //System.out.println(st);
                  StepSts = "Object found";
                  }catch(Exception e){
                        Reporter.log("Error " + e.getMessage());  
                        StepSts=null;
                }
      Thread.sleep(4000);
      if(StepSts==null)
      {
            GenericLibrary.setCellData("Click on Category Management Button","User should be able to click Category Management Button","Unable to Click on Category Management Button","Fail");
        statusList.add(false);
        Sts=false;
          Reporter.log("Click on Category Management Button operation is Unsuccessfull");
          result = false;
      }else
      {
            GenericLibrary.setCellData("Click on Category Management Button","user should be able to click Category Management Button","Click on Category Management Button is Successful","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Click on Category Management Button operation is successfull");
        result = true;
      }
        
  }catch(Exception ex)
  {
      Reporter.log("Error " + ex.getMessage());  
  }
      
return result; 
}

/*---------------------- New method------------------------ */

public boolean clickLoginBtn(WebDriver drv)
{
  boolean result=false;
  try{
      IplanLoginPage pag2 = new IplanLoginPage(drv);  
      boolean StepSts = pag2.clickLoginBtn();
      Thread.sleep(4000);
      if(StepSts==false)
      {
            GenericLibrary.setCellData("Click on Login Button","User should be able to Click Login Button","Unable to Click on Login Button","Fail");
        statusList.add(false);
        Sts=false;
          Reporter.log("Login Button Click Operation is Unsuccessfull");
          result = false;
      }else
      {
            GenericLibrary.setCellData("Click on Login Button","user should be able to Click on Login Button","Login Button Click Operation is Successful","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Login Button Click Operation is successfull");
        result = true;
      }
        
  }catch(Exception ex)
  {
      Reporter.log("Error " + ex.getMessage());  
  }
      
return result; 
}


//===================
public boolean Patient_Information_Name(WebDriver drv)
{
  boolean result=false;	
  try{
	Page_Patient_Information pag3 = new Page_Patient_Information(drv);  
	String Actual=pag3.NameField().getText();
	System.out.println(Actual);
	String expected="Name: BAILEY BETTERS";
	if(!Actual.equalsIgnoreCase(expected))
	{
		GenericLibrary.setCellData("Verify Patient Name",Actual,expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient Name is not valid one");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail",Actual,expected);
	}else
	{
		GenericLibrary.setCellData("Verify Patient Name",Actual,expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient Name is valid one");
        result = true;
        ExtentReport.classAInstance.logReport("Pass",Actual,expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean Patient_DOB(WebDriver drv)
{
  boolean result=false;	
  try{
	Page_Patient_Information pag3 = new Page_Patient_Information(drv); 
	Thread.sleep(4000);
	String Actual=pag3.Birth_Date().getText();
	System.out.println(Actual);
	String expected="Birth Date: 02-16-1982";
	if(!Actual.equalsIgnoreCase(expected))
	{
		GenericLibrary.setCellData("Verify Patient DOB",Actual,expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient DOB is not valid one");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail",Actual,expected);
	}else
	{
		GenericLibrary.setCellData("Verify Patient DOB",Actual,expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient DOB is valid one");
        result = true;
        ExtentReport.classAInstance.logReport("Pass",Actual,expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean Patient_EmailAddress(WebDriver drv)
{
  boolean result=false;	
  try{
	Page_Patient_Information pag3 = new Page_Patient_Information(drv); 
	Thread.sleep(4000);
	String Actual=pag3.Email_Address().getText();
	System.out.println(Actual);
	String expected="test123@test.com";
	if(!Actual.equalsIgnoreCase(expected))
	{
		GenericLibrary.setCellData("Verify Patient Email Address",Actual,expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient Email Address is not valid one");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail",Actual,expected);
	}else
	{
		GenericLibrary.setCellData("Verify Patient Email Address",Actual,expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient Email Address is valid one");
        result = true;
        ExtentReport.classAInstance.logReport("Pass",Actual,expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean Patient_ID(WebDriver drv)
{
  boolean result=false;	
  try{
	Page_Patient_Information pag3 = new Page_Patient_Information(drv); 
	Thread.sleep(4000);
	String Actual=pag3.Patient_ID().getText();
	System.out.println(Actual);
	String expected="Patient ID: 8921600";
	if(!Actual.equalsIgnoreCase(expected))
	{
		GenericLibrary.setCellData("Verify Patient ID",Actual,expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient ID is not valid one");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail",Actual,expected);
	}else
	{
		GenericLibrary.setCellData("Verify Patient ID",Actual,expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient ID is valid one");
        result = true;
        ExtentReport.classAInstance.logReport("Pass",Actual,expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean Gender(WebDriver drv)
{
  boolean result=false;	
  try{
	Page_Patient_Information pag3 = new Page_Patient_Information(drv);
	Thread.sleep(4000);
	String Actual=pag3.Gender().getText();
	System.out.println(Actual);
	String expected="Gender: F";
	if(!Actual.equalsIgnoreCase(expected))
	{
		GenericLibrary.setCellData("Verify Patient Gender",Actual,expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient Gender is not valid one");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", Actual,expected);
	}else
	{
		GenericLibrary.setCellData("Verify Patient Gender",Actual,expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient Gender is valid one");
        result = true;
        ExtentReport.classAInstance.logReport("Pass", Actual,expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean Address(WebDriver drv)
{
  boolean result=false;	
  try{
	Page_Patient_Information pag3 = new Page_Patient_Information(drv); 
	Thread.sleep(4000);
	String Actual=pag3.Address().getText();
	System.out.println(Actual);
	String expected="Address: 123 SESAME ST ATTN MEGAN BIDDEFORD, ME 04005";
	if(!Actual.equalsIgnoreCase(expected))
	{
		GenericLibrary.setCellData("Verify Patient Address",Actual,expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Patient Address is not valid one");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", Actual,expected);
	}else
	{
		GenericLibrary.setCellData("Verify Patient Address",Actual,expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Patient Address is valid one");
        result = true;
        ExtentReport.classAInstance.logReport("Pass", Actual,expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean UpdateMyProfileLink(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  UpdateMyProfile pag3 = new UpdateMyProfile(drv);
	  try{
		  Thread.sleep(4000);
		  pag3.UpdateProfile().click();
	    	StepSts = "Object found";
	    	}catch(Exception e){
	    		Reporter.log("Error " + e.getMessage());  
	    		StepSts=null;
	    	}
	
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on Update My Profile Link","Update My Profile link should work","Update My Profile link is not working","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Click on Update My Profile Link failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Update My Profile link should work","Update My Profile link is not working");
	}else
	{
		GenericLibrary.setCellData("Click on Update My Profile Link","Update My Profile link should work","Update My Profile link is working Properly","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Update My Profile Link is working");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Update My Profile link should work","Update My Profile link is working Properly");
	}
	  
  
	
 return result; 
}

public boolean PhoneLink(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	UpdateMyProfile pag3 = new UpdateMyProfile(drv);  
	try{
		Thread.sleep(4000);
		    pag3.Phone().click();
	    	StepSts = "Object found";
	    	}catch(Exception e){
	    		Reporter.log("Error " + e.getMessage());  
	    		StepSts=null;
	    	}
	
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on Phone Link","Phone link should work","Phone link is not working","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Click on Phone Link failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Phone link should work","Phone link is not working");
	}else
	{
		GenericLibrary.setCellData("Click on Phone Link","Phone link should work","Phone link is working Properly","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Phone Link is working");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Phone link should work","Phone link is working Properly");
	}
	  
  
	
 return result; 
}

public boolean PhoneNumTxtFld(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	UpdateMyProfile pag3 = new UpdateMyProfile(drv); 
	
	try{
		Thread.sleep(4000);
	pag3.Phone_Num().clear();
	Thread.sleep(4000);
	pag3.Phone_Num().sendKeys("2072891010");
	StepSts="Object found";
	}catch(Exception e){
		Reporter.log("Error " + e.getMessage());  
		StepSts=null;
	}
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Enter Valid Phone num","Valid Phone Num Shuolud be entered","Valid Phone num not accepted","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Entering Valid Phone num Failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Valid Phone Num Shuolud be entered","Valid Phone num not accepted");
	}else
	{
		GenericLibrary.setCellData("Enter Valid Phone num","Valid Phone Num Shuolud be entered","Valid Phone num accepted","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Valid Phone num Entered -Pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Valid Phone Num Shuolud be entered","Valid Phone num accepted");
	}
	  
  
	
 return result; 
}

public boolean SubmitButton(WebDriver drv) throws Exception
{
  boolean result=false;	
 
	UpdateMyProfile pag3 = new UpdateMyProfile(drv); 
	try{Thread.sleep(4000);
		pag3.Submitbtn().click();
		StepSts="Object found";
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());  
			StepSts=null;
		}
	
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Submit the changes","Changes should be submitted","Unable to submit the changes","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Changes not updated");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Changes should be submitted","Unable to submit the changes");
	}else
	{
		GenericLibrary.setCellData("Submit the changes","Changes should be submitted","Unable to submit the changes","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Changes updated");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Changes should be submitted","Unable to submit the changes");
	}
	  
  
	
 return result; 
}

public boolean SccMsgVerify(WebDriver drv)
{
  boolean result=false;	
  try{
	UpdateMyProfile pag3 = new UpdateMyProfile(drv); 
	Thread.sleep(4000);
	String Actual=pag3.Success_msg().getText();
	System.out.println(Actual);
	String Expected="Phone Number Changed Successfully.";
	if(!Actual.equalsIgnoreCase(Expected))
	{
		GenericLibrary.setCellData("Verify Phone num success msg",Actual,Expected,"Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Phone num success msg verification failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail",Actual,Expected);
	}else
	{
		GenericLibrary.setCellData("Verify Phone num success msg",Actual,Expected,"Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Phone num success msg verification Pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass",Actual,Expected);
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}

public boolean RefillablePrescription(WebDriver drv) throws Exception
{
  boolean result=false;	
 
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		    pag.Refill_Button().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on Refill Prescription Button","Refill Prescription Button should open Request refill","Refill Prescription Button not opened Request refill","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Refill Prescription failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "Refill Prescription Button should open Request refill","Refill Prescription Button not opened Request refill");
	}else
	{
		GenericLibrary.setCellData("Click on Refill Prescription Button","Refill Prescription Button should open Request refill","Refill Prescription Button  opened Request refill","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Refill Prescription Pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass", "Refill Prescription Button should open Request refill","Refill Prescription Button  opened Request refill");
	}
	  
 
 return result; 
}


public boolean RxNum(WebDriver drv) throws Exception
{
  boolean result=false;	
 
	  Request_Refill pag = new Request_Refill(drv);
	  try{Thread.sleep(4000);
		    pag.Rx_Num().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	  Thread.sleep(5000);
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on Rx Num Link","Rx Num Link should open Request refill","Rx Num Link not opened Request refill","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Rx Num Link Refill failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Rx Num Link should open Request refill","Rx Num Link not opened Request refill");
	}else
	{
		GenericLibrary.setCellData("Click on Rx Num Link","Rx Num Link should open Request refill","Rx Num Link opened Request refill","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Rx Num Link Refill Pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Rx Num Link should open Request refill","Rx Num Link opened Request refill");
	}
	  
 	
 return result; 
}

public boolean IUnderstand(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		    pag.Understand().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on I Understand","I Understand should open Request refill","I Understand not opened Request refill","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("I Understand failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","I Understand should open Request refill","I Understand not opened Request refill");
	}else
	{
		GenericLibrary.setCellData("Click on I Understand","I Understand should open Request refill","I Understand opened Request refill","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("I Understand Pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","I Understand should open Request refill","I Understand opened Request refill");
	}
	  
  
	
 return result; 
}

public boolean FirstName(WebDriver drv) throws Exception
{
  boolean result=false;	
  Request_Refill pag = new Request_Refill(drv); 
  try{Thread.sleep(4000);
	    pag.FirstName().clear();
	    Thread.sleep(4000);
	    pag.FirstName().sendKeys("BAILEY123");;
		StepSts="Object found";
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());  
			StepSts=null;
		}

	  
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Enter first nmae","first name should be updated","first name not been be updated","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("First Name updation failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","first name should be updated","first name not been be updated");
	}else
	{
		GenericLibrary.setCellData("Enter first nmae","first name should be updated","first name been be updated","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("First Name updation pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","first name should be updated","first name been be updated");
	}
	  

 return result; 
}

public boolean LastName(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv);
	  try{Thread.sleep(4000);
		  pag.LastName().clear();
		  Thread.sleep(4000);
		  pag.LastName().sendKeys("BAILEY456");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Enter Last nmae","Last name should be updated","Last name not been be updated","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Last Name updation failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Last name should be updated","Last name not been be updated");
	}else
	{
		GenericLibrary.setCellData("Enter Last nmae","Last name should be updated","Last name been be updated","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Last Name updation pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Last name should be updated","Last name been be updated");
	}
	  	
 return result; 
}

public boolean DateofBirth(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv);
	  try{
		  Thread.sleep(4000);
		  pag.Birth_Date().clear();
		  Thread.sleep(4000);
		  pag.Birth_Date().sendKeys("05/05/1990");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Enter Date of Birth","Date of Birth should be updated","Date of Birth not been be updated","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Date of Birth updation failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Date of Birth should be updated","Date of Birth not been be updated");
	}else
	{
		GenericLibrary.setCellData("Enter Date of Birth","Date of Birth should be updated","Date of Birth been be updated","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Date of Birth updation pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass", "Date of Birth should be updated","Date of Birth been be updated");
	}
	  
  
 return result; 
}

public boolean Calander(WebDriver drv) throws Exception
{
  boolean result=false;	

	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
	      //List<WebElement> allDates=(List<WebElement>) pag.Delivery_Date();
	  
	  WebElement myele=pag.Delivery_Date();
	  myele.click();
	  List<WebElement> allDates=myele.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
	      for(WebElement ele:allDates)
			{
	    	  boolean date=ele.isEnabled();
	    	  if(date==true)
	    	  {
	    		  Actions act = new Actions(drv).moveToElement(ele).doubleClick();
	    		  act.build().perform();
	    		 //ele.click(); 
	    		 break;
	    	  }
				
			}
		 // pag.Delivery_Date().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on calander","calander should open","calander dint opened","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("opening calander failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","calander should open","calander dint opened");
	}else
	{
		GenericLibrary.setCellData("Click on calander","calander should open","calander opened","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("opening calander pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","calander should open","calander opened");
	}

 return result; 
}

public boolean Selectdate(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.Date_Selection().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on calander","calander should open","calander dint opened","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("opening calander failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","calander should open","calander dint opened");
	}else
	{
		GenericLibrary.setCellData("Click on calander","calander should open","calander opened","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("opening calander pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","calander should open","calander opened");
	}
	  
 
 return result; 
}

public boolean supply_medication (WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv);
	  try{Thread.sleep(4000);
		  pag.days_supply().sendKeys("8");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("enter num of days for supply","supply num of days should be entered","supply num of days not entered","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log(" num of days for supply failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "supply num of days should be entered","supply num of days not entered");
	}else
	{
		GenericLibrary.setCellData("enter num of days for supply","supply num of days should be entered","supply num of days entered","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log(" num of days for supply pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","supply num of days should be entered","supply num of days entered");
	}
	
 return result; 
}

public boolean medication_changes(WebDriver drv) throws Exception
{
  boolean result=false;	

	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.changes_Medica().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Provide medication changes","No","No","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("medication changes failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "Provide medication changes","unable Provide medication changes");
	}else
	{
		GenericLibrary.setCellData("Provide medication changes","No","No","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("medication changes pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Provide medication changes","Able Provide medication changes");
	}
	
 return result; 
}

public boolean latexAllergies (WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.latex_allergies().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("developed any new food, drug, environmental, or latex allergies","No","No","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("developed any new food, drug, environmental, or latex allergies failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "developed any new food, drug, environmental, or latex allergies","UnAble to develop any new food, drug, environmental, or latex allergies");
	}else
	{
		GenericLibrary.setCellData("developed any new food, drug, environmental, or latex allergies","No","No","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("developed any new food, drug, environmental, or latex allergies pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","developed any new food, drug, environmental, or latex allergies","Able to develop any new food, drug, environmental, or latex allergies");
	}
	  
 return result; 
}

public boolean pharmacist(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.pharmacist().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("have any questions for the pharmacist about your medication treatment","No","No","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("have any questions for the pharmacist about your medication treatment failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "Have any questions for the pharmacist about your medication treatment","No");
	}else
	{
		GenericLibrary.setCellData("have any questions for the pharmacist about your medication treatment","No","No","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("have any questions for the pharmacist about your medication treatment pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Have any questions for the pharmacist about your medication treatment","No");
	}

 return result; 
}

public boolean NurseAdminister(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv);
	  try{Thread.sleep(4000);
		  pag.administer().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Will a home health nurse administer this medication","No","No","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Will a home health nurse administer this medication failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Will a home health nurse administer this medication","No");
	}else
	{
		GenericLibrary.setCellData("Will a home health nurse administer this medication","No","No","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Will a home health nurse administer this medication pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Will a home health nurse administer this medication","No");
	}
	  
 return result; 
}

public boolean additional_comments(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.additional().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Do you have any additional comments or instructions?","No","No","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Do you have any additional comments or instructions failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Do you have any additional comments or instructions?","No");
	}else
	{
		GenericLibrary.setCellData("Do you have any additional comments or instructions?","No","No","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Do you have any additional comments or instructions? pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Do you have any additional comments or instructions?","No");
	}
	 
	
 return result; 
}

public boolean CreditCardInfo(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.Lastfour_digits().sendKeys("0987");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Enter Credit card info","valid credit card num should be accepted","valid credit card num not accepted","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Entering Valid credit card info failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","valid credit card num should be accepted","valid credit card num not accepted");
	}else
	{
		GenericLibrary.setCellData("Enter Credit card info","valid credit card num should be accepted","valid credit card num accepted","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Entering Valid credit card info pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","valid credit card num should be accepted","valid credit card num accepted");
	}

	
 return result; 
}

public boolean ExpiryMonth(WebDriver drv) throws Exception
{
  boolean result=false;	
 
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.Month("05");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Select Credit card expiry month","Selection of expiry month should be valid","Selection not possible","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Select Credit card expiry month failed");
	    result = false;
	}else
	{
		GenericLibrary.setCellData("Select Credit card expiry month","Selection of expiry month should be valid","Selection Possible","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Select Credit card expiry month pass");
        result = true;
	}
 return result; 
}

public boolean ExpiryYear(WebDriver drv) throws Exception
{
  boolean result=false;	
 
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.Year("2020");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Select Credit card expiry Year","Selection of expiry Year should be valid","Selection not possible","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Select Credit card expiry Year failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Selection of expiry Year should be valid","Selection not possible");
	}else
	{
		GenericLibrary.setCellData("Select Credit card expiry Year","Selection of expiry Year should be valid","Selection Possible","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Select Credit card expiry Year pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Selection of expiry Year should be valid","Selection Successful");
	}
	  
  
 return result; 
}

public boolean MaxAmount(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv);
	  try{Thread.sleep(4000);
		  pag.Amount().sendKeys("12");
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	 
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Enter max amount in dollars","Dollar amount should be entered","unable to enter Dollar amount","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Enter max amount in dollars failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Dollar amount should be entered","unable to enter Dollar amount");
	}else
	{
		GenericLibrary.setCellData("Enter max amount in dollars","Dollar amount should be entered","able to enter Dollar amount","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Enter max amount in dollars pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Dollar amount should be entered","able to enter Dollar amount");
	}

 return result; 
}

public boolean Acceptence(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		   pag.Accept().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	 
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on I Accept","should be clicked","unable to click","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Click on I Accept failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","should be clicked","unable to click");
	}else
	{
		GenericLibrary.setCellData("Click on I Accept","should be clicked","able to click","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Click on I Accept pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","should be clicked","able to click");
	}
	
 return result; 
}

public boolean Continue_review(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.Continue().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on Continue and review","should be clicked","unable to click","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Click on Continue and review failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Click on Continue and review,should be clicked","unable to click");
	}else
	{
		GenericLibrary.setCellData("Click on Continue and review","should be clicked","able to click","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Click on Continue and review pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Click on Continue and review","able to click");
	}
	  
 
 return result; 
}

public boolean Submit_request(WebDriver drv) throws Exception
{
  boolean result=false;	
  
	  Request_Refill pag = new Request_Refill(drv); 
	  try{Thread.sleep(4000);
		  pag.Submit_Request().click();
			StepSts="Object found";
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());  
				StepSts=null;
			}
	 
	  
	if(StepSts==null)
	{
		GenericLibrary.setCellData("Click on Submit and request","should be clicked","unable to click","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("Click on Submit and request failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail", "Click on Submit and request,should be clicked","unable to click");
	}else
	{
		GenericLibrary.setCellData("Click on Submit and request","should be clicked","able to click","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("Click on Submit and request pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Click on Submit and request,should be clicked","able to click");
	}

	
 return result; 
}

public boolean VerifyStatus(WebDriver drv)
{
  boolean result=false;	
  try{
	  Request_Refill pag = new Request_Refill(drv);
	  Thread.sleep(4000);
	  String A=pag.Thank_You().getText();
	  String B="";
	if(A.equals(B))
	{
		GenericLibrary.setCellData("Verify the refill request","Request refill should be submitted successfully","unable to submit the Request refil","Fail");
        statusList.add(false);
        Sts=false;
	    Reporter.log("submission of refill request failed");
	    result = false;
	    ExtentReport.classAInstance.logReport("Fail","Request refill should be submitted successfully","unable to submit the Request refil");
	}else
	{
		GenericLibrary.setCellData("Verify the refill request","Request refill should be submitted successfully","able to submit the Request refil","Pass");
        Sts=true;
        statusList.add(true);
        Reporter.log("submission of refill request pass");
        result = true;
        ExtentReport.classAInstance.logReport("Pass","Request refill should be submitted successfully","able to submit the Request refil");
	}
	  
  }catch(Exception ex)
  {
	Reporter.log("Error " + ex.getMessage());  
  }
	
 return result; 
}
}
