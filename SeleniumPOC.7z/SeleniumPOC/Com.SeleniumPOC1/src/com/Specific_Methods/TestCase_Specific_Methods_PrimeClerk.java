package com.Specific_Methods;

import java.awt.List;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Driver;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.DriverScript.MasterScript;
import com.Pom_PrimeClerk.PrimeClerkWelcomePage;
import com.Pom_PrimeClerk.PrimeClerkHomePage;
import com.Pom_PrimeClerk.PrimeClerkLoginPage;
import com.Pom_PrimeClerk.PrimeClerkManageDocPage;
import com.Pom_PrimeClerk.PrimeClerkMenuPage;
import com.UtilityFiles.CommonUtils;
import com.UtilityFiles.Constants;
import com.UtilityFiles.ExtentReport;
import com.UtilityFiles.GenericLibrary;
//import com.mongodb.MapReduceCommand.OutputType;
import com.UtilityFiles.ExtentReport;
import com.UtilityFiles.GenericLibrary;
import com.prop.PropData;
import com.sun.jna.platform.FileUtils;

public class TestCase_Specific_Methods_PrimeClerk {
public ArrayList<Boolean> statusList=new ArrayList<Boolean>();
Boolean Sts = false;
String StepSts;
private static final String ExpectedErr = null;
private static final String ActualErr = null;
public static String expectedCaseName;
public static String expectedCaseNumber;
public static String copyIplanName;
public static String categoryName;
public static String updateCaseName;
public static String parentWindow=CommonUtils.drv.getWindowHandle();

/*
================================================================================================ 
 -Method Name: selectDropDown
 -Description: All dropdown selection methods presents in different pages are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean selectDropDown(WebDriver drv, String PageName, String ElementName)
 
{
    boolean result=false;
	String DropDownValue = null;

		switch(PageName) {
		
		case "PrimeClerkWelcomePage" :
			PrimeClerkWelcomePage pcHomePg = new PrimeClerkWelcomePage(drv);
			try{
				if(ElementName.equalsIgnoreCase("caseName")){
					DropDownValue = PropData.loadProp().getProperty("PrimeClerkWelcomePage_CaseName");	
				    result = pcHomePg.selectCaseName(DropDownValue);
				    }
	           }
			catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}	
			break;
			
		case "PrimeClerkMenuPage" :
			break;
		
		}
	
	try{
		String Steps = "Select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
		if(result=false)
		{						
			String Expected  = "User should be able to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
			String Actual = "Unable to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page is NOT successfull");
			result = false;				
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);				
							
		}else
		{
			String Expected = "User should be able to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";
			String Actual = "Able to select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page";		
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Select '"+DropDownValue +"' from '"+ElementName+"' dropdown in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}



/*
================================================================================================ 
 -Method Name: clickButton
 -Description: All Button click methods presents in different pages are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By:
 ================================================================================================
 */
public boolean clickButton(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	WebDriverWait wait=new WebDriverWait(CommonUtils.drv,20);

	switch(PageName) {

	case "PrimeClerkLoginPage" :
		
		PrimeClerkLoginPage loginpage = new PrimeClerkLoginPage(drv);					
		try{
		if(ElementName.equalsIgnoreCase("Login Button")){
		result = loginpage.clickLoginBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "PrimeClerkHomePage" :
		PrimeClerkWelcomePage homePage = new PrimeClerkWelcomePage(drv);
		try{ 
		if(ElementName.equalsIgnoreCase("LogOutBtn")){
			result = homePage.clickLogoutBtn();
			}
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}
	break;
	
	case "PrimeClerkMenuPage" :
		PrimeClerkMenuPage menuPage = new PrimeClerkMenuPage(drv);
		
		try{
			if(ElementName.equalsIgnoreCase("SubmitBtn")){
			result = menuPage.clickSubmitBtn();
			}
			else if(ElementName.equalsIgnoreCase("RefreshBtn")){
			result = menuPage.clickRefreshBtn();
			}else if(ElementName.equalsIgnoreCase("Browse Button")){
				result = menuPage.clickBrowseBtn();
			}else if(ElementName.equalsIgnoreCase("Upload Button")){
					result = menuPage.clickUploadBtn();
			}else if(ElementName.equalsIgnoreCase("Debtor Button")){
			WebElement button=menuPage.clickDebtorBtn();
			Thread.sleep(2000);
			WebElement TextElement = button.findElement(By.xpath("//span[text()='PrimePOC(16-16744)']"));
			wait.until(ExpectedConditions.elementToBeClickable(TextElement));
			TextElement.click();
			result=true;
			}else if(ElementName.equalsIgnoreCase("Document Type")){
		     WebElement button=menuPage.clickDocTypeBtn();
		     Thread.sleep(2000);
		     button.findElement(By.xpath("//span[text()='POC']")).click();
		     result=true;
			}else if(ElementName.equalsIgnoreCase("Document Source")){
	        WebElement button=menuPage.clickDocSourceBtn();
	         Thread.sleep(2000);
	         button.findElement(By.xpath("//span[text()='Manual Upload']")).click();
	         result=true;
			}else if(ElementName.equalsIgnoreCase("Add Button")){
				result=menuPage.clickAddBtn();
				Thread.sleep(2000);
			}else if(ElementName.equalsIgnoreCase("Address Type")){
					WebElement button=menuPage.clickAddrTypeBtn();
					Thread.sleep(2000);
					WebElement TextElement = button.findElement(By.xpath("//span[text()='Primary Address']"));
					wait.until(ExpectedConditions.elementToBeClickable(TextElement));
					TextElement.click();
					result=true;
           }else if(ElementName.equalsIgnoreCase("Search Button")){
        	   result=menuPage.clickSearchBtn();
        	   Thread.sleep(2000);
       
	        }else if(ElementName.equalsIgnoreCase("Delete Doc Button")){
	        	result=menuPage.clickDeleteDocBtn();
	        	Thread.sleep(2000);
	         }else if(ElementName.equalsIgnoreCase("Update Doc Button")){
	        	result=menuPage.clickUpdateDocBtn();
	        	Thread.sleep(2000);
               
			}else if(ElementName.equalsIgnoreCase("Save and Continue")){
	        	result=menuPage.clickSaveContBtn();
	        	Thread.sleep(2000);
            	
			}else if(ElementName.equalsIgnoreCase("Search MML")){
				result=menuPage.clickSearchMMLBtn();
				Thread.sleep(2000);
			
			}else if(ElementName.equalsIgnoreCase("Select MML")){
				result=menuPage.clickChkBox();
				Thread.sleep(2000);
				 
			}else if(ElementName.equalsIgnoreCase("Selected MML Record Button")){
				result=menuPage.clickSelMMLRecBtn();
				closeChildWindow(parentWindow);
				Thread.sleep(2000);
			 
			}else if(ElementName.equalsIgnoreCase("Support Doc Flag as Yes")){
				result=menuPage.clickFlagChkBox();
				Thread.sleep(2000);
		    
			
      		}else if(ElementName.equalsIgnoreCase("Click OK Button")){
      			result=menuPage.clickOKBtn();
      			Thread.sleep(2000);
      		
		   	}else if(ElementName.equalsIgnoreCase("Save and Done")){
				result=menuPage.clickSaveDoneBtn();
				Thread.sleep(2000);
  		}
			}catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}
		
	break;
	}
	/*	
	case "IplanCopyFromSourcePage" :
		
		IplanCopyFromSourcePage cpyfromsrc = new IplanCopyFromSourcePage(drv);
		try{
		if(ElementName.equalsIgnoreCase("OK")){
		result = cpyfromsrc.clickOkBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "IplanCopyFromSrcEditPlanPage" :
		
		IplanCopyFromSrcEditPlanPage cpyfromeditsrc = new IplanCopyFromSrcEditPlanPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Copy Next")){
		result = cpyfromeditsrc.iplanCopyNextBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;
		
	case "IplanCopyDetailsPage" :
		
		IplanCopyDetailsPage cpyplndetails = new IplanCopyDetailsPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Submit Plan Details")){
		result = cpyplndetails.iplanCopyPlnDtlSubmitBtn();
		}
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;		
		

	}
*/
	try{
		
		String Steps = "Click on '"+ElementName+"' Button in '"+PageName+"' Page";
		String Expected = "User Should be able to click on '"+ElementName+"' Button in '"+PageName+"' Page";

		if(result==false)
		{						
			String Actual = "Unable to Click on '"+ElementName+"' Button in '"+PageName+"' Page";
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Click on '"+ElementName+"' Button in '"+PageName+"' Page is NOT successfull");
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			result = false;						
		}else
		{	
			String Actual = "Able to Click on '"+ElementName+"' Button in '"+PageName+"' Page";						
			GenericLibrary.setCellData("Click on '"+ElementName+"' in '"+PageName+"' Page","User Should be able to click on '"+ElementName+"' in '"+PageName+"' Page","Able to Click on '"+ElementName+"' in '"+PageName+"' Page","Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Click on '"+ElementName+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);					
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: check/uncheck Check boxes
 -Description: All Button clickcheck/uncheck Check boxes methods are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By:
 ================================================================================================
 */
/*public boolean selectCheckBox(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);

		break;
		
	case "IplanCategoryPage" :
		
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);					
		try{
		if(ElementName.equalsIgnoreCase("Uncheck Active Status")){
		result = CatPage.selectChkBoxtToInactive();
		}
		
		}catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		break;

	}

	try{
		String Steps = null;
		String Expected = null;					
		String[] strArr = ElementName.split(" ");
		{
		if(strArr[0].equalsIgnoreCase("Uncheck")){
		Steps = "Uncheck '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		Expected = "User Should be able to Uncheck '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		
		}else{					
		Steps = "Check '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		Expected = "User Should be able to Check '"+strArr[1]+" "+strArr[2]+"' check box in '"+PageName+"' Page";
		}	
		}
		
		if(result==false)
		{	
			String Actual = "NOT able to "+Expected.replace("User Should be able to", " ")+" ";											
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Click on '"+ElementName+"' in '"+PageName+"' Page is NOT successfull");
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);				
			//ExtentReport.classAInstance.logReport("Fail","Screnshot Below",GenericLibrary.snapShot(Steps+".jpg", MasterScript.ScreenShotPath));
			//String screenpath = TestCase_Specific_Methods.capture(drv, Steps.replace("'", ""));						
			//ExtentReport.classAInstance.logReport("Fail", Steps,Actual,screenpath);
			
			result = false;
		}else
		{
			
			String Actual = "Able to "+Expected.replace("User Should be able to", " ")+" ";
			GenericLibrary.setCellData("Click on '"+ElementName+"' in '"+PageName+"' Page","User Should be able to click on '"+ElementName+"' in '"+PageName+"' Page","Able to Click on '"+ElementName+"' in '"+PageName+"' Page","Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Click on '"+ElementName+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
			
			//String screenpath = TestCase_Specific_Methods.capture(drv, Steps.replace("'", ""));
			//ExtentReport.classAInstance.logReport("Fail", Steps,Actual,screenpath);
			
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: clickLink
 -Description: All click on Link methods present in different pages are called here
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean clickLink(WebDriver drv, String PageName, String ElementName)
{
	boolean result=false;
	switch(PageName) {
		
	case "PrimeClerkHomePage" :		
		PrimeClerkHomePage pcHomePg = new PrimeClerkHomePage(drv);
		if(ElementName.equalsIgnoreCase("Manage Document")){
			result = pcHomePg.clickManageDocs();
		}
		break;
		
	case "PrimeClerkManageDocPage" :		
		PrimeClerkManageDocPage pcMgDocPg = new PrimeClerkManageDocPage(drv);
		if(ElementName.equalsIgnoreCase("Add Document")){
			result = pcMgDocPg.clickAddDocBtn();	
		
		}
		break;	
		
		
	case "PrimeClerkMenuPage" :
		
		PrimeClerkMenuPage pcMenuPg = new PrimeClerkMenuPage(drv);
		
		try{
			
		if(ElementName.equalsIgnoreCase("caseSetup")){
			result = pcMenuPg.clickCaseSetup();	
		}
		else if(ElementName.equalsIgnoreCase("addSubCase")){
			result = pcMenuPg.clickAddSubCase();
			
		}else if(ElementName.equalsIgnoreCase("Edit Record")){
				result = pcMenuPg.clickEditRecordLink();
		
		}else if(ElementName.equalsIgnoreCase("Delete Record")){
			result = pcMenuPg.ClickDeleteRecordLink();
		
	    }else if(ElementName.equalsIgnoreCase("Document Processing")){
		result = pcMenuPg.clickDocProceesingLink(); 
		
     	}else if(ElementName.equalsIgnoreCase("POC")){
		result = pcMenuPg.clickPOClink();
		
    	}else if(ElementName.equalsIgnoreCase("Input Doc")){
		result = pcMenuPg.clickInputDocLink();
		
	}
	   }catch(Exception e){
		Reporter.log("Error " + e.getMessage());
		result = false;
	   }

		break;

	}

	try{
		
		String Steps ="Click on '"+ElementName+"' Link in '"+PageName+"' Page";
		String Expected = "User Should be able to click on '"+ElementName+"' Link in '"+PageName+"' Page";

		if(result==false)
		{
			String Actual = "Unable to Click on '"+ElementName+"' Link in '"+PageName+"' Page";						
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Click on '"+ElementName+"' Link in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			
		}else
		{
			String Actual = "Able to Click on '"+ElementName+"' Link in '"+PageName+"' Page";
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Click on '"+ElementName+"' Link in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	


/*
================================================================================================ 
 -Method Name: enterText
 -Description: Method to enter text value in text box
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 Username
 ================================================================================================
 */
public boolean enterText(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String EnterTextValue = null;
	
	switch(PageName) {

	case "PrimeClerkLoginPage" :
		
		  PrimeClerkLoginPage loginpage = new PrimeClerkLoginPage(drv);
		try{
			if(ElementName.equalsIgnoreCase("LineUser1_ID")){				
			EnterTextValue	=  PropData.loadProp().getProperty("LineUser1_ID");		
			result = loginpage.enterID(EnterTextValue);
			}
			else if(ElementName.equalsIgnoreCase("LineUser1_PWD")){			
				EnterTextValue	=  PropData.loadProp().getProperty("LineUser1_PWD");
				expectedCaseName = EnterTextValue;
				result = loginpage.enterPwd(EnterTextValue);
			}
			else if(ElementName.equalsIgnoreCase("Password")){
				EnterTextValue	=  Constants.PWD_Prime;
				expectedCaseNumber = EnterTextValue;
				//result = loginpage.inputPassword(EnterTextValue);
				
			}
			
		 }catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		    }
			break;

					
		
		
	case "PrimeClerkHomePage" :
		PrimeClerkWelcomePage homePage = new PrimeClerkWelcomePage(drv);
		break;
		
	case "PrimeClerkMenuPage" :
		
		PrimeClerkMenuPage menuPage = new PrimeClerkMenuPage(drv);
		
		try{
			if(ElementName.equalsIgnoreCase("subCaseName")){				
			EnterTextValue	=  PropData.loadProp().getProperty("PrimeClerkMenuPage_subCaseName");
			result = menuPage.inputsubCaseName(EnterTextValue);
			}
			else if(ElementName.equalsIgnoreCase("subCaseNumber")){
			EnterTextValue	=  PropData.loadProp().getProperty("PrimeClerkMenuPage_subCaseNumber");
			result = menuPage.inputsubCaseNumber(EnterTextValue);			
		    }
			else if(ElementName.equalsIgnoreCase("Description")){
			EnterTextValue	=  PropData.loadProp().getProperty("PrimeClerkMenuPage_subCaseNumber");
			result = menuPage.inputDescTxt(EnterTextValue);
	       	}else if(ElementName.equalsIgnoreCase("Docket Number")){
			EnterTextValue	=  Constants.docketNumber_Prime;
			result = menuPage.inputDocketNumTxt(EnterTextValue);
	     
	 	}else if(ElementName.equalsIgnoreCase("Search Number")){
			EnterTextValue	=  Constants.docketNumber_Prime;
			result = menuPage.inputSearchTxt(EnterTextValue);
		     }
	 
		 }catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		    }
			break;

	       }

	try{

		String Steps = "Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";
		String Expected = "User Should be able to Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";
		if(result==false)
		{
			String Actual= "Unable to Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";			
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			
		}else
		{
			String Actual= "Able to Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page";				
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Enter text '"+EnterTextValue+"' value in '"+ElementName+"' Text Box in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
	
}	


/*
================================================================================================ 
 -Method Name: verifyText
 -Description: Method to verifyText text value
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 */
public boolean verifyText(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String ExpectedTextValue = null;
	String ActualTextValue = null;

	switch(PageName) {

	case "PrimeClerkLoginPage" :
		
		PrimeClerkLoginPage loginpage = new PrimeClerkLoginPage(drv);
					
		break;
		
	case "PrimeClerkMenuPage" :
		PrimeClerkMenuPage menuPage = new PrimeClerkMenuPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("VerifyCaseNumber")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("PrimeClerkMenuPage_verifyCaseNumber");			
			ActualTextValue = menuPage.getCaseNumber();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}
		
		
		
		/*else if (ElementName.equalsIgnoreCase("Verify Exisitng Category Error")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_ExistingCategoryError");			
			ActualTextValue = CatPage.getExistCatError();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}else if (ElementName.equalsIgnoreCase("Search Result Record")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_ZeroRecordsMatch");			
			ActualTextValue = CatPage.getCatRecords();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}
	*/				
		}	catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}

		
		break;
		}

	try{
		
		String Steps = "Verify text  '"+ExpectedTextValue+"' of '"+ElementName+"' is present in '"+PageName+"' Page";
		String Expected = "Text '"+ExpectedTextValue+"' should be present in '"+PageName+"' Page";
		String Actual = "Text '"+ActualTextValue+"' is Present in '"+PageName+"' Page";
		
		if(result==false)
		{
							
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Text verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
		}else
		{				
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Text verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is NOT successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	

/*
================================================================================================ 
 -Method Name: verifyCheckBoxStatus
 -Description: Method to verifyText text value
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 
public boolean verifyCheckBoxStatus(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String ExpectedTextValue = null;
	String ActualTextValue = null;

	switch(PageName) {

	case "IplanLoginPage" :
		
		IplanLoginPage loginpage = new IplanLoginPage(drv);
					
		break;
		
	case "IplanCategoryPage" :
		
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Disabled")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_InactiveStatusValue");			
			ActualTextValue = CatPage.getcheckBoxStatusDisabled();
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}
		}
						
		}	catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}

		break;
	}
	

	try{
		
		String Steps = "Verify check box status  '"+ExpectedTextValue+"' in '"+PageName+"' Page";
		String Expected = "Check box status should be '"+ExpectedTextValue+"' in '"+PageName+"' Page";
		String Actual = "Check box status is '"+ActualTextValue+"' in '"+PageName+"' Page";
		if(result==false)
		{	
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Check box status verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
		}else
		{
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Check box status verification for '"+ElementName+"' of value '"+ExpectedTextValue+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
		}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}

/*
================================================================================================ 
 -Method Name: verifyAlert
 -Description: Method to verifyText text value
 -Author: Galaxe QA Automation Team
 -Last Modified Date: 5/10/2017
 -Modified By: 
 ================================================================================================
 
public boolean verifyAlert(WebDriver drv, String PageName, String ElementName) throws InterruptedException
{
	boolean result=false;
	String ExpectedTextValue = null;
	String ActualTextValue = null;
	Alert alert = null;
	
	try{
		alert= drv.switchTo().alert();
		ActualTextValue = alert.getText();
		//Thread.sleep(4000);		
	  }	catch(Exception e){
		Reporter.log("Error " + e.getMessage());
		result = false;
	  }

	switch(PageName) {
	
	case "IplanCategoryPage" :
		IplanCategoryPage CatPage = new IplanCategoryPage(drv);
		try{
		if(ElementName.equalsIgnoreCase("Alert Cat_Name_Required")){				
		    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_VerifyforCatNameNull");	
			if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
			result = true;
			}else{
			result = false;
			}			
		}		
		}	catch(Exception e){
			Reporter.log("Error " + e.getMessage());
			result = false;
		}
		
		try{
			if(ElementName.equalsIgnoreCase("Delete Alert")){				
			    ExpectedTextValue	=  PropData.loadProp().getProperty("IplanCategoryPage_DeleteAlert");	
				if(ExpectedTextValue.equalsIgnoreCase(ActualTextValue)){
				result = true;
				}else{
				result = false;
				}			
			}		
			}	catch(Exception e){
				Reporter.log("Error " + e.getMessage());
				result = false;
			}
		
		break;
	}
	

	try{
		
		String Steps = "Verify alert text  '"+ExpectedTextValue+"' for '"+ElementName+"' is present in '"+PageName+"' Page";			
		String Expected = "Alert text '"+ActualTextValue+"' should be Present for '"+ElementName+"' in '"+PageName+"' Page";
		String Actual = "Alert text '"+ActualTextValue+"' is Present in '"+PageName+"' Page";			
		
		if(result==false)
		{
			GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
			statusList.add(false);
			Sts=false;
			Reporter.log("Verification of Alert text '"+ExpectedTextValue+"' for '"+ElementName+"' in '"+PageName+"' Page is NOT successfull");
			result = false;
			ExtentReport.classAInstance.logReport("Fail", Steps,Actual);
			alert.accept();
			drv.switchTo().defaultContent();
			}else
		    {
			GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
			Sts=true;
			statusList.add(true);
			Reporter.log("Verification of Alert text '"+ExpectedTextValue+"' for '"+ElementName+"' in '"+PageName+"' Page is successfull");
			result = true;
			ExtentReport.classAInstance.logReport("Pass",Steps,Actual);
			alert.accept();
			drv.switchTo().defaultContent();
			}

	}catch(Exception ex)
	{
		Reporter.log("Error " + ex.getMessage());  
	}   
	return result; 
}	



/*
================================================================================================ 



//take Screen shot----
     
    public static String capture(WebDriver drv,String screenShotName) throws IOException
    {
        TakesScreenshot ts = (TakesScreenshot)drv;
        File source = ts.getScreenshotAs(OutputType.FILE);
        String dest = MasterScript.ScreenShotPath+screenShotName+".png";
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);        
                     
        return dest;
    }
*/

	/*================================================================================================ 
			 -Method Name: Switch to frame
			 -Description: Switching from one frame to another frame
			 -Author: Galaxe QA Automation Team
			 -Last Modified Date: 5/30/2017
			 -Modified By: 
			 ================================================================================================ */
    
	public boolean switchToFrame(WebDriver drv, String PageName, String FrameName)
	{
	boolean result=false;
	try{
		  try{
			  drv.switchTo().frame(drv.findElement(By.id("ifrmcontent")));
              StepSts = "Object found";
	        }catch(Exception e){
	          Reporter.log("Error " + e.getMessage());
	          e.printStackTrace();
	           StepSts=null;
	           }
	    if(StepSts==null)
	    {
	        GenericLibrary.setCellData("Switch to "+FrameName+" frame window","User should be able to Switch to "+FrameName+" frame window in "+PageName+" page","Unble to Switch to "+FrameName+" frame window in "+PageName+" page","Fail");
	        statusList.add(false);
	        Sts=false;
	        Reporter.log("Switch to frame is NOT successfull");
	        ExtentReport.classAInstance.logReport("Fail", "Switch to "+FrameName+" frame window","Unble to Switch to "+FrameName+" frame window in "+PageName+" page");
	        result = false;
	    }else
	    {
	      GenericLibrary.setCellData("Switch to "+FrameName+" frame window","User should be able to Switch to "+FrameName+" frame window in "+PageName+" page","Able to Switch to "+FrameName+" frame window in "+PageName+" page","Pass");
	      Sts=true;
	      statusList.add(true);
	      Reporter.log("Switch to frame is successfull");
	      ExtentReport.classAInstance.logReport("Pass", "Switch to "+FrameName+" frame window","Able to Switch to "+FrameName+" frame window in "+PageName+" page");
	      result = true;
	    }
	      
	}catch(Exception ex)
	{
	 Reporter.log("Error " + ex.getMessage());  
	}	    
	return result; 
	}


	/*================================================================================================ 
			 -Method Name: selectCurrentDate
			 -Description: All dropdown selection methods presents in different pages are called here
			 -Author: Galaxe QA Automation Team
			 -Last Modified Date: 5/30/2017
			 -Modified By: 
			 ================================================================================================ */
	
	public boolean selectCurrentDate(WebDriver drv, String PageName, String ElementName)
	{
	  boolean result=false;

			switch(PageName) {
		
			case "PrimeClerkLoginPage" :
				break;
		
			case "PrimeClerkHomePage" :
		
				break;
				
			case "PrimeClerkMenuPage" :
		
				PrimeClerkMenuPage pcMenuPg = new PrimeClerkMenuPage(drv);
				try{
					if(ElementName.equalsIgnoreCase("Petition Date")){
						result = pcMenuPg.inputpetitionDate();	
					}
					else if(ElementName.equalsIgnoreCase("Filed Date")){
						result = pcMenuPg.inputFiledDate();			
		            }
					else if(ElementName.equalsIgnoreCase("Claim Filing Date")){
						result = pcMenuPg.selectClmfilingDate();			
		            }
				}
				catch(Exception e){
					Reporter.log("Error " + e.getMessage());
					result = false;
				}
				break;
					
		
			}
			
			
			try{
				String Steps = "Select current date' for '"+ElementName+"' from '"+PageName+"' Page";
				if(result=false)
				{						
					String Expected  = "Select current date' for '"+ElementName +"' from '"+PageName+"' Page";
					String Actual = "Unable to select current date' for '"+ElementName +"' from '"+PageName+"' Page";
					GenericLibrary.setCellData(Steps,Expected,Actual,"Fail");
					statusList.add(false);
					Sts=false;
					Reporter.log("Select current date' for '"+ElementName +"' from '"+PageName+"' Page is NOT successfull");
					result = false;				
					ExtentReport.classAInstance.logReport("Fail", Steps,Actual);				
									
				}else
				{
					String Expected = "User should be able to select current date' for '"+ElementName +"' from '"+PageName+"' Page";
					String Actual = "Able to select current date' for '"+ElementName +"' from '"+PageName+"' Page";		
					GenericLibrary.setCellData(Steps,Expected,Actual,"Pass");
					Sts=true;
					statusList.add(true);
					Reporter.log("Select current date' for '"+ElementName +"' from '"+PageName+"' Page is successfull");
					result = true;
					ExtentReport.classAInstance.logReport("Pass", Steps,Actual);
				}

			}catch(Exception ex)
			{
				Reporter.log("Error " + ex.getMessage());  
			}   
			
			return result;
	}

	
	
	/*================================================================================================ 
	 -Method Name: inputRandomName
	 -Description: Random name generation for unique alphanumeric value
	 -Author: Galaxe QA Automation Team
	 -Last Modified Date: 5/30/2017
	 -Modified By: 
	 ================================================================================================ */
	
	
	
	/*================================================================================================ 
	 -Method Name: inputRandomNumber
	 -Description: Random number generated for unique numeric value
	 -Author: Galaxe QA Automation Team
	 -Last Modified Date: 5/30/2017
	 -Modified By: 
	 ================================================================================================ */
    
	
	/*================================================================================================ 
	 -Method Name: loginPCPortal
	 -Description: Login to Prime clerk portal
	 -Author: Galaxe QA Automation Team
	 -Last Modified Date: 5/30/2017
	 -Modified By: 
	 ================================================================================================ */
	
	
	public boolean LoginPrimeClerk(WebDriver drv,String userName,String pass)
	{
		
	  boolean result=false;	
	  try{
		  PrimeClerkLoginPage p1 = new PrimeClerkLoginPage(drv); 
		  Thread.sleep(4000);
		 // result=p1.inputUserName(userName); 
		Thread.sleep(4000);
		 // p1.inputPassword(pass);
		Thread.sleep(4000);
		//p1.clickLoginBtn();
		Thread.sleep(4000);
		String expectedTitle= "Prime Clerk";
		String actualTitle = drv.getTitle();
		System.out.println(actualTitle);
		if(!expectedTitle.equalsIgnoreCase(expectedTitle))
		{
			GenericLibrary.setCellData("Login to Prime Clerk Application with valid credentilas","user should be able Login to Prime Clerk Application with valid credentilas","Unable Login to Prime Clerk Application with valid credentilas","Fail");
	        statusList.add(false);
	        Sts=false;
		    Reporter.log("Login to Prime Clerk application is NOT successfull");
		    ExtentReport.classAInstance.logReport("Fail", "Login to Prime Clerk Application with valid credentilas","Unable Login to Prime Clerk Application with valid credentilas");
		    result = false;
		}else
		{
			GenericLibrary.setCellData("Login to Prime Clerk Application with valid credentilas","user should be able Login to Prime Clerk Application with valid credentilas","Login to Prime Clerk Application with valid credentilas successfull","Pass");
	        Sts=true;
	        statusList.add(true);
	        Reporter.log("Login to Prime Clerk application is successfull");
	        ExtentReport.classAInstance.logReport("Pass", "Login to Prime Clerk Application with valid credentilas","Able Login to Prime Clerk Application with valid credentilas");
	        result = true;
		}
		  
	  }catch(Exception ex)
	  {
		Reporter.log("Error " + ex.getMessage());  
	  }
		
	 return result; 
	}
	/*================================================================================================ 
	 -Method Name: verifyCaseName
	 -Description: Search data from webtable and veify text
	 -Author: Galaxe QA Automation Team
	 -Last Modified Date: 5/30/2017
	 -Modified By: 
	 ================================================================================================ */
	public boolean verifyCaseName(WebDriver drv)
	{ 
	  boolean result=false;

	  PrimeClerkMenuPage pag2 = new PrimeClerkMenuPage(drv);
	  try{
	      int rowCount=drv.findElements(By.xpath("//table[@id='sdtable']/tbody/tr")).size(); 
	  for (int i=2;i<=rowCount;i++){
		  String actualCaseNumber= drv.findElement(By.xpath("//table[@id='sdtable']/tbody/tr["+i+"]/td[2]")).getText();

	      actualCaseNumber=actualCaseNumber.replace("-","");
		  Thread.sleep(1000);  
		  if(actualCaseNumber.equalsIgnoreCase(expectedCaseNumber)) {
		      //Thread.sleep(1000);
		      try{
		      drv.findElement(By.xpath("//table[@id='sdtable']/tbody/tr["+i+"]/td[5]/img[1]")).click();
		      Thread.sleep(2000);
		      drv.switchTo().frame(drv.findElement(By.id("ifrmcontent")));
		      drv.findElement(By.name("SubCaseName")).click();
		      String actualCaseName1= drv.findElement(By.name("SubCaseName")).getAttribute("value");
		      Thread.sleep(2000);
		      System.out.println("actual case name is"+actualCaseName1);
		      Thread.sleep(2000);
		      System.out.println("expected case name is"+expectedCaseName);
		      Thread.sleep(1000);
		      drv.switchTo().defaultContent();
		      //Thread.sleep(4000);
		      pag2.clickSubmitBtn();
		      Thread.sleep(2000);
		      if(actualCaseName1.equalsIgnoreCase(expectedCaseName)){
		    	  Thread.sleep(4000);
		    	  StepSts = "Object found";
			     
		      }
		      
		      
		      
	  }catch(Exception ex)
		      
	  {
		  Reporter.log("Error " + ex.getMessage()); 
	   }
		      if(StepSts== null)
		      {
		        GenericLibrary.setCellData("Verification of added case name in sub Debtor table","User should be able to verify added case name in sub debtor table","Added case name not available in sub sebtor table","Fail");
		        statusList.add(false);
		        Sts=false;
		          Reporter.log("Case name verification in sub Debtor table is NOT successful");
		          ExtentReport.classAInstance.logReport("Fail", "Verification of added case name in sub Debtor table","Added case name not available in sub sebtor table");
		          
		          result = false;
		      }else
		      {
		        GenericLibrary.setCellData("Verification of added case name in sub Debtor table","User should be able to verify added case name in sub debtor table","Added case name available in sub sebtor table","Pass");
		        Sts=true;
		        statusList.add(true);
		        Reporter.log("Case name verification in sub Debtor table is successfully");
		        ExtentReport.classAInstance.logReport("Pass", "Verification of added case name in sub Debtor table","Added case name available in sub sebtor table");
		        result = true;
		      }
		  }
	  }
	  
		  }catch(Exception ex)
			  {
			      Reporter.log("Error " + ex.getMessage());  
			  }

				  return result;
	}
	  

	/*================================================================================================ 
	 -Method Name: deleteRowdata
	 -Description: Delete any specific row from webtable
	 -Author: Galaxe QA Automation Team
	 -Last Modified Date: 5/30/2017
	 -Modified By: 
	 ================================================================================================ */

	public boolean deleteRowData(WebDriver drv)
	{ 
	  boolean result=false;

	  PrimeClerkMenuPage pag2 = new PrimeClerkMenuPage(drv);
	  try{
		  
	  pag2.clickRefreshBtn();
	  int rowCount=drv.findElements(By.xpath("//table[@id='sdtable']/tbody/tr")).size(); 
	  for (int i=2;i<=rowCount;i++){
		 String actualCaseNumber= drv.findElement(By.xpath("//table[@id='sdtable']/tbody/tr["+i+"]/td[2]")).getText();

	      actualCaseNumber=actualCaseNumber.replace("-","");
		  Thread.sleep(1000);
	// to find row where case number matching	  
		  if(actualCaseNumber.equalsIgnoreCase(expectedCaseNumber)) {
		      Thread.sleep(1000);
		      try{
		      drv.findElement(By.xpath("//table[@id='sdtable']/tbody/tr["+i+"]/td[5]/img[2]")).click();
		      Thread.sleep(2000);
		      pag2.clickDeleteBtn();
		      Thread.sleep(1000);

	  }catch(Exception ex)
		      
	  {
		  ex.printStackTrace();
		  Reporter.log("Error " + ex.getMessage()); 
	   }
		      if(StepSts== null)
		      {
		        GenericLibrary.setCellData("Deletion of added case name in tabe","User should be able to Delete added case name in sub debtor table","Unable to delete case name  available in sub sebtor table","Fail");
		        statusList.add(false);
		        Sts=false;
		          Reporter.log("Case name Deletion Debtor table is NOT successful");
		          ExtentReport.classAInstance.logReport("Fail", "Deletion of added case name in sub Debtor table","Unable to delete case name  available in sub sebtor table");
		          result = false;
		      }else
		      {
		        GenericLibrary.setCellData("Deletion of added case name in sub Debtor table","User should be able to Delete added case name in sub debtor table","able to delete case name  available in sub sebtor table","Pass");
		        Sts=true;
		        statusList.add(true);
		        Reporter.log("Case name Deletion in sub Debtor table is successfully");
		        ExtentReport.classAInstance.logReport("Pass", "Deletion of added case name in sub Debtor table","Able to delete case name  available in sub sebtor table");
		        result = true;
		      }
		  
		  }
	  }
	  
		  }catch(Exception ex)
			  {
	 	  ex.printStackTrace();
			      Reporter.log("Error " + ex.getMessage());  
			  }

				  return result;
	  
	  }




//-----set a clipboard

public static void setClipboardData(String string) {
    //StringSelection is a class that can be used for copy and paste operations.
       StringSelection stringSelection = new StringSelection(string);
       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
    }

public static void uploadDocument(String string){
	 boolean result =false;
	 
	 
	 String fileLocation=Constants.file_Path;
try {
  //to find parent window 
	
    //System.out.println("parent window id is :"+ parentWindow);
    //Thread.sleep(2000); 
	 Robot robot = new Robot();
	 robot.keyPress(KeyEvent.VK_TAB);
  	robot.keyPress(KeyEvent.VK_SPACE);
	Thread.sleep(1000);
	robot.keyRelease(KeyEvent.VK_SPACE);
//Setting clipboard with file location
	Thread.sleep(4000);
	setClipboardData(fileLocation);
//native key strokes for CTRL, V and ENTER keys


robot.keyPress(KeyEvent.VK_CONTROL);
robot.keyPress(KeyEvent.VK_V);
robot.keyRelease(KeyEvent.VK_V);
robot.keyRelease(KeyEvent.VK_CONTROL);

robot.keyPress(KeyEvent.VK_ENTER);
robot.keyRelease(KeyEvent.VK_ENTER);

Thread.sleep(1000);
robot.keyPress(KeyEvent.VK_ENTER);
Thread.sleep(6000);
closeChildWindow(parentWindow);
CommonUtils.drv.switchTo().frame(CommonUtils.drv.findElement(By.id("ifrmcontent")));
result =true;
} catch (Exception exp) {
exp.printStackTrace();
result =false;
}


if(result==false){
       
       //statusList.add(false);
       //Sts=false;
       Reporter.log("Setting upload path Operation is Unsuccessfull");
       result = false;
}else
{
       try {
		GenericLibrary.setCellData("Set Upload path for Document","user should be able  to Set Upload path","Upload Set Upload Path Operation is Successful","Pass");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      // Sts=true;
      // statusList.add(true);
       Reporter.log("Setting upload path Operation is successfull");
       result = true;
}

}


public static void closeChildWindow(String parentWindow) throws InterruptedException{
	
	Set<String> windows=CommonUtils.drv.getWindowHandles();
	for(String currentWin: windows){
	if(!currentWin.equals(parentWindow)){
	CommonUtils.drv.switchTo().window(currentWin).close();
	}
	}
	Thread.sleep(2000);
	CommonUtils.drv.switchTo().window(parentWindow);
}

public boolean updatePOC(WebDriver drv)
{ 
	  boolean result=false;

	  PrimeClerkMenuPage pag2 = new PrimeClerkMenuPage(drv);
	  try{
	      int rowCount=drv.findElements(By.xpath("//table[@id='jqTable']/tbody/tr")).size(); 
	  for (int i=2;i<=rowCount;i++){
		//table[@id='jqTable']/tbody/tr[4]/td[3]
		  String actualDocketNumber= drv.findElement(By.xpath("//table[@id='jqTable']/tbody/tr["+i+"]/td[3]")).getText();
          String expectedDocketNumber=Constants.docketNumber_Prime;
	     
		  if(actualDocketNumber.equalsIgnoreCase(expectedDocketNumber)) {
		      Thread.sleep(1000);
		      try{
		      drv.findElement(By.xpath("//table[@id='jqTable']/tbody/tr["+i+"]/td[4]/a")).click();
		      Thread.sleep(4000);
		      closeChildWindow(parentWindow);
		      drv.switchTo().frame(CommonUtils.drv.findElement(By.id("ifrmcontent")));
		     /*
		      String updateCaseName1= drv.findElement(By.name("SubCaseName")).getAttribute("value");
		      updateCaseName=updateCaseName1;
		      if(!updateCaseName.equalsIgnoreCase(expectedCaseName)){
		    	  StepSts = "Object found and updated";
		    	  System.out.println("case name updated successfully");
		      }
		      Thread.sleep(4000);
		      drv.switchTo().defaultContent();
		      Thread.sleep(4000);
		      pag2.clickSubmitBtn();
		 */     	      
	  }catch(Exception ex)
		      
	  {
		  Reporter.log("Error " + ex.getMessage()); 
	   }
		      if(StepSts== null)
		      {
		        GenericLibrary.setCellData("Update case name in sub Debtor table","User should be able to Update case name in sub debtor table","Case name not updated in sub sebtor table","Fail");
		        statusList.add(false);
		        Sts=false;
		          Reporter.log("Case name updation in sub Debtor table is NOT successful");
		          ExtentReport.classAInstance.logReport("Fail", "Update case name in sub Debtor table","Case name not updated in sub sebtor table");
		          result = false;
		      }else
		      {
		        GenericLibrary.setCellData("Update case name in sub Debtor table","User should be able to Update case name in sub debtor table","Case name updated in sub sebtor table","Pass");
		        Sts=true;
		        statusList.add(true);
		        Reporter.log("Case name updation in sub Debtor table is successful");
		        ExtentReport.classAInstance.logReport("Pass", "Update case name in sub Debtor table","Case name updated in sub sebtor table");
		        result = true;
		      }
		  }
	  }
	  
		  }catch(Exception ex)
			  {
			      Reporter.log("Error " + ex.getMessage());  
			  }

				  return result;
	  
	  }


/*================================================================================================ 
-Method Name: 
-Description: Delete any specific row from webtable
-Author: Galaxe QA Automation Team
-Last Modified Date: 5/30/2017
-Modified By: 
================================================================================================ */


}

