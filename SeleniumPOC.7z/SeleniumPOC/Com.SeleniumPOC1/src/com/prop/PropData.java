package com.prop;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import com.UtilityFiles.FPath;

public abstract class PropData {
	
	public static Properties OR;	
	public static String PathPropFile = FPath.PROP_FILE;
	
	public static Properties loadProp(){
	FileInputStream fs = null;
	try {
		fs = new FileInputStream(PathPropFile);	
	    OR= new Properties(System.getProperties());	
		OR.load(fs);
		return OR;
	} catch (IOException e) {
		e.printStackTrace();
		return null;
	}
		
	
	}

}
