package com.Pom_BriovaRx;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class IplanLoginPage {     
    
    public IplanLoginPage(WebDriver driver) {
          PageFactory.initElements(driver, this);
    
    }
    
    @FindBy(xpath = "//select[contains(@id,'cphIPlan_ddlUser')]")
    private WebElement list;
    
    public WebElement List_Profile(String profile) {
          Select stat=new Select(list);
          try{
         stat.selectByVisibleText(profile);
          }catch(Exception e){
                list=null; 
           }
          return list;
    }
    
    @FindBy(xpath = "//input[contains(@id,'_cphIPlan_btnLogin')]")
    private WebElement LoginBtn;
    
    
    public  boolean clickLoginBtn () {
          try{
               LoginBtn.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
          
          
    }
    @FindBy(xpath = ".//a[@title='Manage Category']")
    private WebElement ManageCatLink;
    
    

}

