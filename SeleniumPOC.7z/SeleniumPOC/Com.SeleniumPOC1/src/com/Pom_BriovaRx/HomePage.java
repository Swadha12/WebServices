package com.Pom_BriovaRx;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HomePage {

		public HomePage(WebDriver drv) {
			PageFactory.initElements(drv, this);
		}
		
		@FindBy(id = "LOGIN_OPTION_TYPE")
		private WebElement list;
		
		public WebElement List_Patient(String profile) {
			 Select stat=new Select(list);
			 try{
		     stat.selectByVisibleText(profile);
			 }catch(Exception e){
				 list=null; 
			 }
			 return list;
		}
		
		

}
