package com.TestCases.PrimeClerk;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import com.Specific_Methods.TestCase_Specific_Methods_PrimeClerk;
import com.UtilityFiles.CommonFunctions;
import com.UtilityFiles.CommonUtils;
import com.UtilityFiles.Constants;
import com.UtilityFiles.FPath;

public class POCProcess {   
    FPath FP;
    CommonFunctions common;
    CommonUtils com;
    TestCase_Specific_Methods_PrimeClerk spm;      
    Constants con;
    CommonUtils com1 = new CommonUtils();
    WebDriver drv;
    public ArrayList<Boolean> statusList1 = null;

    
    /* Pre condition*/
    
    public boolean preCond() throws InterruptedException
    {
        
        try {
        	  drv = com1.getDriverObject();
              FP=new FPath();
              common=new CommonFunctions();
              spm=new TestCase_Specific_Methods_PrimeClerk();
        } catch (Exception e) {                
              e.printStackTrace();
        }
        return false;
    }
  
    /* Post condition*/
  public boolean postCond()
    {
        try {
              drv.close();
              drv.quit();
        } catch (Exception e) {
              e.printStackTrace();
        }
        return false;
    }
  
     
 public boolean uploadPOCDocument() throws InterruptedException{
       preCond();       
       statusList1 = new ArrayList<Boolean>();
           try {
             spm.enterText(drv,"PrimeClerkLoginPage" , "LineUser1_ID");
             spm.enterText(drv,"PrimeClerkLoginPage" , "LineUser1_PWD");
             spm.clickButton(drv,"PrimeClerkLoginPage" , "Login Button");
             spm.selectDropDown(drv,"PrimeClerkWelcomePage", "caseName");
             spm.clickLink(drv, "PrimeClerkHomePage", "Manage Document");
             spm.clickLink(drv, "PrimeClerkManageDocPage", "Add Document");
             spm.switchToFrame(drv,"PrimeClerkManageDocPage","Add Document");             
             spm.uploadDocument(Constants.file_Path);            
             spm.clickButton(drv, "PrimeClerkMenuPage", "Debtor Button");
             spm.selectCurrentDate(drv, "PrimeClerkMenuPage", "Filed Date");
             spm.enterText(drv, "PrimeClerkMenuPage", "Docket Number");
             spm.enterText(drv, "PrimeClerkMenuPage", "Description");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Document Source");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Document Type");
             drv.switchTo().defaultContent();            
             spm.clickButton(drv, "PrimeClerkMenuPage", "Add Button");
             spm.enterText(drv, "PrimeClerkMenuPage", "Search Number");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Search Button");
             spm.clickLink(drv, "PrimeClerkMenuPage", "Document Processing");
             spm.clickLink(drv, "PrimeClerkMenuPage", "POC");
             spm.clickLink(drv, "PrimeClerkMenuPage", "Input Doc");             
             spm.switchToFrame(drv,"PrimeClerkMenuPage","Input Doc");
             spm.updatePOC(drv);
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Continue");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Support Doc Flag as Yes");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Search MML");
             spm.switchToFrame(drv,"PrimeClerkMenuPage","Search MML");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Address Type");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Search Button");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Select MML");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Selected MML Record Button");
             drv.switchTo().defaultContent();
             //spm.clickButton(drv, "PrimeClerkMenuPage", "Support Doc Flag as Yes");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Continue");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Click OK Button");
             spm.selectCurrentDate(drv, "PrimeClerkMenuPage", "Claim Filing Date");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Debtor Button");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Continue");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Continue");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Continue");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Continue");
             spm.clickButton(drv, "PrimeClerkMenuPage", "Save and Done");  
             spm.clickLink(drv, "PrimeClerkMenuPage", "Document Processing");
             spm.clickLink(drv, "PrimeClerkMenuPage", "POC");
             spm.clickButton(drv, "PrimeClerkHomePage", "LogoutBtn");             
             // login as input2 user             
             spm.enterText(drv,"PrimeClerkLoginPage" , "Input2");
             spm.enterText(drv,"PrimeClerkLoginPage" , "Password");
             spm.clickButton(drv,"PrimeClerkLoginPage" , "Login Button");
             spm.clickLink(drv, "PrimeClerkMenuPage", "Document Processing");
             spm.clickLink(drv, "PrimeClerkMenuPage", "POC");
             spm.clickLink(drv, "PrimeClerkMenuPage", "Input Doc");

           
           } catch (Exception e) {
           Reporter.log("Error " + e.getMessage());        
          }
       postCond();
       statusList1.addAll(spm.statusList);
       return statusList1.contains(false);
    }

 
 public boolean addCategoryNeg() throws InterruptedException{
     preCond();       
     statusList1 = new ArrayList<Boolean>();
         try {
             spm.selectDropDown(drv,"IplanLoginPage","LogIn Profile");        
             spm.clickButton(drv,"IplanLoginPage","LogIn");
             spm.clickLink(drv,"IplanMenuOptionPage","Manage Category");
             spm.clickButton(drv,"IplanCategoryPage","Add Category");
             spm.enterText(drv,"IplanCategoryPage","Existing Category Name");                
             spm.clickButton(drv,"IplanCategoryPage","Save Category");
             spm.verifyText(drv,"IplanCategoryPage","Verify Exisitng Category Error");
             spm.clickButton(drv,"IplanLoginPage","LogOut");
          } catch (Exception e) {
         Reporter.log("Error " + e.getMessage());        
        }
     postCond();
     statusList1.addAll(spm.statusList);
     return statusList1.contains(false);
  }
 
 
 
 public boolean deleteCategory() throws InterruptedException{
     // preCond();
     // Refill();
      System.out.println("deleteCategory");
     // postCond();
     // statusList1.addAll(spm.statusList);
      return statusList1.contains(false);
}
 
 
 
 

}
