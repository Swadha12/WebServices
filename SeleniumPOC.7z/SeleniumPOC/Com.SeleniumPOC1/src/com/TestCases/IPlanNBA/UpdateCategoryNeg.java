package com.TestCases.IPlanNBA;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;


import com.Specific_Methods.TestCase_Specific_Methods_IPlan_NBA;
import com.UtilityFiles.CommonFunctions;
import com.UtilityFiles.CommonUtils;
import com.UtilityFiles.Constants;
import com.UtilityFiles.FPath;

public class UpdateCategoryNeg {
	
	// TODO Auto-generated method stub
			FPath FP;
		    CommonFunctions common;
		    CommonUtils com;
		    TestCase_Specific_Methods_IPlan_NBA spm;      
		    Constants con;
		    WebDriver drv;
		    CommonUtils com1 = new CommonUtils();
		    public ArrayList<Boolean> statusList1=new ArrayList<Boolean>();
		    
		    public boolean UpdateCategoryNeg() throws InterruptedException{
		          preCond();
		          Refill();
		          postCond();
		          statusList1.addAll(spm.statusList);
		          return statusList1.contains(false);
		    }
		    public boolean preCond() throws InterruptedException
		      {
		          
		          try {
		                drv=com1.getDriverObject(Constants.BRW_NAME_FF,Constants.URL_IPlan);
		                FP=new FPath();
		                common=new CommonFunctions();
		                spm=new TestCase_Specific_Methods_IPlan_NBA();
		                //dr=com1.getDriverObject();
		          } catch (Exception e) {
		                
		                e.printStackTrace();
		          }
		          return false;
		      }
		    
		    public boolean Refill()
		    {
		          boolean tc_res = false;
		          try {
		                spm.selectDropDown(drv,"IplanLoginPage","LogIn Profile");        
		                spm.clickButton(drv,"IplanLoginPage","LogIn");
		                spm.clickLink(drv,"IplanMenuOptionPage","Manage Category");
		                spm.enterText(drv,"IplanCategoryPage","Search Category Name");
		                spm.clickButton(drv,"IplanCategoryPage","Search Category");
		                spm.clickButton(drv,"IplanCategoryPage","Update Category");   
		                spm.enterText(drv,"IplanCategoryPage","Category Name Null");
		                spm.clickButton(drv,"IplanCategoryPage","Update");
		                spm.verifyAlert(drv,"IplanCategoryPage","Alert Cat_Name_Required");
		                spm.clickButton(drv,"IplanLoginPage","LogOut");
		          } catch (Exception e) {
		                Reporter.log("Error " + e.getMessage()); 
		                tc_res = false;
		          }
		          return tc_res;
		    }
		    public boolean postCond(){
		          try {
		                drv.close();
		                drv.quit();
		          } catch (Exception e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		          }
		          return false;
		      }

		}


