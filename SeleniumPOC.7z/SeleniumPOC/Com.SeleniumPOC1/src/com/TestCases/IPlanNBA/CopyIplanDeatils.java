package com.TestCases.IPlanNBA;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.Specific_Methods.TestCase_Specific_Methods_IPlan_NBA;
import com.UtilityFiles.CommonFunctions;
import com.UtilityFiles.CommonUtils;
import com.UtilityFiles.Constants;
import com.UtilityFiles.FPath;

public class CopyIplanDeatils {   
    FPath FP;
    CommonFunctions common;
    CommonUtils com;
    TestCase_Specific_Methods_IPlan_NBA spm;      
    Constants con;
    WebDriver drv;
    CommonUtils com1 = new CommonUtils();
    public ArrayList<Boolean> statusList1=new ArrayList<Boolean>();
    
    public boolean CopyIplanDeatils() throws InterruptedException{
          preCond();
          Refill();
          postCond();
          statusList1.addAll(spm.statusList);
          return statusList1.contains(false);
    }
    public boolean preCond() throws InterruptedException
      {
          
          try {
                drv=com1.getDriverObject(Constants.BRW_NAME_FF,Constants.URL_IPlan);
                FP=new FPath();
                common=new CommonFunctions();
                spm=new TestCase_Specific_Methods_IPlan_NBA();
             } catch (Exception e) {
                
                e.printStackTrace();
          }
          return false;
      }
    
    public boolean Refill()
    {
          boolean tc_res = false;
          try {
        	  
              spm.selectDropDown(drv,"IplanLoginPage","LogIn Profile");        
              spm.clickButton(drv,"IplanLoginPage","LogIn");
              spm.clickLink(drv,"IplanMenuOptionPage","Copy I-Plan");
              spm.selectDropDown(drv,"IplanCopyFromSourcePage","Select Season");
              spm.selectDropDown(drv,"IplanCopyFromSourcePage","Select Plan");
              spm.clickButton(drv,"IplanCopyFromSourcePage","OK");
              spm.enterText(drv,"IplanCopyFromSrcEditPlanPage","Preferred PlanName");
              spm.selectDropDown(drv,"IplanCopyFromSrcEditPlanPage","Select EditedSeason");
              spm.clickButton(drv,"IplanCopyFromSrcEditPlanPage","Copy Next");
              spm.clickButton(drv,"IplanCopyDetailsPage","Submit Plan Details");
              spm.clickButton(drv,"IplanLoginPage","LogOut");
                
          } catch (Exception e) {
                Reporter.log("Error " + e.getMessage()); 
                tc_res = false;
          }
          return tc_res;
    }
    public boolean postCond()
      {
          try {
                drv.close();
                drv.quit();
          } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
          }
          return false;
      }
    

}
