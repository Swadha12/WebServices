package com.TestCases.BriovaRx;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.Specific_Methods.TestCase_Specific;
import com.Specific_Methods.TestCase_Specific_Methods_Briova;
import com.UtilityFiles.CommonFunctions;
import com.UtilityFiles.CommonUtils;
import com.UtilityFiles.Constants;
import com.UtilityFiles.FPath;
public class VerifyPat {
	FPath FP;
	CommonFunctions common;
	CommonUtils com;
	TestCase_Specific_Methods_Briova spm;
	TestCase_Specific sp;
	
	Constants con;
    CommonUtils com1 = new CommonUtils();
    public ArrayList<Boolean> statusList1=new ArrayList<Boolean>();
    
		
	
	
	public boolean VerifyPat() throws InterruptedException{
		
		preCond();
		VerifyPatientInformation();
		postCond();
		statusList1.addAll(sp.statusList);
		return statusList1.contains(false);
		
	}
	
    
	  public  boolean preCond() throws InterruptedException 
	  {
		
		try {
			FP=new FPath();
			common=new CommonFunctions();
			spm=new TestCase_Specific_Methods_Briova();
			sp=new TestCase_Specific();
			//dr=com.getDriverObject();
			com1.getDriverObject(Constants.BRW_NAME_FF,Constants.URL_Briova);
		} catch (Exception e) {
			
			System.out.println(e.getCause());
		}
		return false;
	  }
	
    
	public boolean VerifyPatientInformation()
	{
		boolean tc_res = false;
		
		try {
			
		    sp.SelectProfile(com1.drv);
			sp.LoginBriovaRx(com1.drv, Constants.ID_Briova, Constants.PWD_Briova);
			Thread.sleep(5000);
			sp.Patient_Information_Name(com1.drv);
			sp.Patient_DOB(com1.drv);
			sp.Patient_EmailAddress(com1.drv);
			sp.Patient_ID(com1.drv);
			sp.Gender(com1.drv);
			sp.Address(com1.drv);
			sp.LogoutBriovaRx(com1.drv);
			statusList1.addAll(sp.statusList);
			statusList1.addAll(sp.statusList);
			return statusList1.contains(false);
			
		} catch (Exception e)
		{
			Reporter.log("Error " + e.getMessage()); 	
			tc_res = false;
		}
		return tc_res;
	}
	
    
	public  boolean postCond()
	  {
		
		  try {
			com1.drv.close();
			  com1.drv.quit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		  
	  }
	  
	  

}
