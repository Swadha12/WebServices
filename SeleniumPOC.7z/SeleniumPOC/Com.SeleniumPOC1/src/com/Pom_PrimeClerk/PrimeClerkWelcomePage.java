package com.Pom_PrimeClerk;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.UtilityFiles.CommonUtils;

public class PrimeClerkWelcomePage {     
    
	WebDriver driver;
	
    public PrimeClerkWelcomePage(WebDriver driver) {
          PageFactory.initElements(driver, this);
          this.driver = driver;
    }
        
    /* --------------------------------------------------------
	Prime Clerk Home Page Elements

	----------------------------------------------------------- */
    
    @FindBy(xpath = "//input[@id='txtselectedcase']")
    private String caseName;
    
    @FindBy(xpath = "//select[@id='ddlCases']")
    private WebElement list;
    
    
    @FindBy(xpath = "//a[@title='Logout']")
    private WebElement LogOutBtn;
    /* --------------------------------------------------------
	Prime Clerk Home Page Methods

	----------------------------------------------------------- */
    
    public String inputCaseName(String caseName) {
         
          return caseName;
    }
    
    
 public WebElement List_CaseName(String profile) {
      Select stat=new Select(list);
      
    try{
        stat.selectByVisibleText(profile);
        list.sendKeys(Keys.ENTER);
      }catch(Exception e){
            list=null; 
       }
      return list;
    }
       
 public boolean selectCaseName(String profile) {    		
    		try{
    			driver=CommonUtils.drv;
    			WebDriverWait wait  = new WebDriverWait(driver,20);
    			wait.until(ExpectedConditions.elementToBeClickable(list));
    			Select stat=new Select(list);
    			stat.selectByVisibleText(profile);
    		}catch(Exception e){
    			return false;
    		}
    		return true;
    	}

 public  boolean clickLogoutBtn () {
 	   try{
 		driver = CommonUtils.drv;
 	    WebDriverWait wait  = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.elementToBeClickable(LogOutBtn));
           return true;
        }catch(Exception e){
           return false; 
        }

 } 
    
}