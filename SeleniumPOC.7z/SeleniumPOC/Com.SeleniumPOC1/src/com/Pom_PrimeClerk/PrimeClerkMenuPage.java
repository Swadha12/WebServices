package com.Pom_PrimeClerk;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PrimeClerkMenuPage {     
    
WebDriver driver;
	
	public PrimeClerkMenuPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
	       PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
	       this.driver=driver;
      }
    
	/* --------------------------------------------------------
	NBA Iplan Category Page Elements

	----------------------------------------------------------- */
	
   @FindBy(xpath = "//a[@title='Logout']")
   private WebElement LogOutBtn;

   @FindBy(xpath = "//a[@title='Case Setup']")
   private WebElement caseSetup;
	
   @FindBy(xpath = "//a[@id='aSubc']")
   private WebElement addSubCase;
   
   @FindBy(id = "SubCaseName")
   private WebElement subCaseName;
   
   @FindBy(id = "SubCaseNumber")
   private WebElement subCaseNumber;
   
   @FindBy(id="CasePetitionDate")
   private WebElement petitionDate;
   
   @FindBy(xpath="//button[@title='Submit']")
   private WebElement SubmitBtn;
   
   @FindBy(xpath="//td[@id='refresh_sdtable']/div/span")
   private WebElement RefreshBtn;
   
   @FindBy(xpath="//div[contains(@class,'ui-helper-clearfix')]/div/button/span[text()='Delete']")
   private WebElement DeleteBtn;   
   

   
   @FindBy(xpath="//input[@id='uploadFile']")
   private WebElement browseDoc;
   
   @FindBy(xpath="//input[@id='btnUpload']")
   private WebElement uploadDoc;
   
   @FindBy(xpath="//select[@id='ClaimDebtorID']/following-sibling::button")
   private WebElement debtorNameBtn;
   
   @FindBy(xpath="//input[@id='UploadedDate']")
   private WebElement filedDate;
   
   @FindBy(xpath="//input[@id='DocketNumber']")
   private WebElement docketNumTxt;
   
   @FindBy(xpath="//textarea[@id='Description']")
   private WebElement descTxt;
   
   @FindBy(xpath="//select[@id='DocumentSourceID']/following-sibling::button")
   private WebElement docSourceBtn;
   
   @FindBy(xpath="//select[@id='DocumentTypeID']/following-sibling::button")
   private WebElement docTypeBtn;
   
   @FindBy(xpath="//button[@title='Add']")
   private WebElement addBtn;
   
   @FindBy(xpath="//input[@id='DocketNumber']")
   private WebElement inputdocketNum;
   
   @FindBy(xpath="//input[@id='btnSearch']")
   private WebElement searchBtn;
   
   @FindBy(xpath="//input[@id='btn_Delete_Document']")
   private WebElement deleteDocBtn;
   
   @FindBy(xpath="//input[@id='btn_Update_Document']")
   private WebElement updateDocBtn;
   
   @FindBy(xpath="//table[@id='jqTable']/tbody/tr[2]/td[15]/img[1]")
   private WebElement editRecordLink;
   
   @FindBy(xpath="//table[@id='jqTable']/tbody/tr[2]/td[15]/img[2]")
   private WebElement deleteRecordLink;
   
   @FindBy(xpath="//a[text()='Document Processing']")
   private WebElement docProceesingLink;
   
   @FindBy(xpath="//a[@title='POC']")
   private WebElement POClink;
   
   @FindBy(xpath="//table[@id='tblPOCLanding']/tbody/tr[3]/td[2]/a/img")
   private WebElement inputDocLink;
   

   @FindBy(xpath="//input[@id='btn_Save_&_Continue']")
   private WebElement saveContBtn;
   
 
   @FindBy(xpath="//input[@id='btnSearchMMLMMLID']")
   private WebElement searchMMLBtn;
	
 
   @FindBy(xpath="//select[@id='lstAddressType']/following-sibling::button")
   private WebElement addrTypeBtn;
   

   @FindBy(xpath="//table[@id='jqTable']/tbody/tr[2]/td[1]/input")
   private WebElement ChkBox;
   

   @FindBy(xpath=" //input[@id='btn_Selected_MML_Record']")
   private WebElement selMMLRecBtn;
   
 
   @FindBy(xpath="//input[@id='SupportDocumentationFlagYes']")
   private WebElement FlagChkBox;
   

   @FindBy(xpath="//span[text()='OK']")
   private WebElement OKBtn;
   
 
   @FindBy(xpath="//input[@id='ClaimFilingDate']")
   private WebElement ClmfilingDate;
   
 
   @FindBy(xpath="//input[@id='btn_Save_&_Done']")
   private WebElement saveDoneBtn;
   
	/* --------------------------------------------------------
	Prime Clerk Menu Page Methods
	----------------------------------------------------------- */
   
   public  WebElement clickLogoutBtn () {
	   WebDriverWait wait  = new WebDriverWait(driver,20);
	   wait.until(ExpectedConditions.elementToBeClickable(LogOutBtn));
	   LogOutBtn.click();
 	   return LogOutBtn;
        
  }

   
    public boolean clickCaseSetup() {
         
    	try{
    		WebDriverWait wait  = new WebDriverWait(driver,20);
    		wait.until(ExpectedConditions.elementToBeClickable(caseSetup));
    		caseSetup.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }

    public boolean clickAddSubCase() {
         
    	try{
    		WebDriverWait wait  = new WebDriverWait(driver,20);
    		wait.until(ExpectedConditions.elementToBeClickable(addSubCase));
    		addSubCase.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }
    

    public boolean inputsubCaseName(String caseName) {
	
		
		try{			
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(subCaseName));			
			subCaseName.click();
			subCaseName.clear();
			subCaseName.sendKeys(caseName);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false; 
		}
        
    }
    

    public boolean inputsubCaseNumber(String caseNumber) {
		
		try{			
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(subCaseNumber));			
			subCaseNumber.click();
			subCaseNumber.clear();
			subCaseNumber.sendKeys(caseNumber);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false; 
		}
        
    }
    
    

    public boolean inputpetitionDate() {
    	try{
    		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    		LocalDateTime now = LocalDateTime.now();
    		String currentDate=dtf.format(now);
    		System.out.println(currentDate);
		    WebDriverWait wait  = new WebDriverWait(driver,20);
		    wait.until(ExpectedConditions.visibilityOf(petitionDate));
		    petitionDate.click();
		    petitionDate.sendKeys(currentDate);
        return true;
    	}catch(Exception e){
    		e.getStackTrace();
    		return false;
    	}
    }


    public  boolean clickSubmitBtn () {
          try{
	       	   WebDriverWait wait  = new WebDriverWait(driver,20);
	    	   wait.until(ExpectedConditions.elementToBeClickable(SubmitBtn));
	           SubmitBtn.click();
	           return true; 
           }catch(Exception e){
               return false; 
           }
   }


    public  boolean clickRefreshBtn() {
          try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(RefreshBtn));
        	  RefreshBtn.click();
              return true; 
           }catch(Exception e){
              return false; 
           }
  }
    
  
    public  boolean clickDeleteBtn() {
          try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(DeleteBtn));
        	  DeleteBtn.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
     }
 
 


	public String getCaseNumber()
	{                 
		try{

			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(subCaseNumber));
			String caseNumber = subCaseNumber.getText();
			return caseNumber; 
		}catch(Exception e){
			return null; 
		}

	}
	
	//browseDoc
    public  boolean clickBrowseBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(browseDoc));
	    	  browseDoc.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}


	public boolean clickUploadBtn() {
	     try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(uploadDoc));
	    	  uploadDoc.click();
           return true; 
        }catch(Exception e){
             return false; 
        }
	     
	}  
	
	//debtorName	
	
	public WebElement clickDebtorBtn() {
	     try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(debtorNameBtn));
	    	  debtorNameBtn.click();
	    	  
          
       }catch(Exception e){
           
       }
	    return debtorNameBtn; 
	}  
	
    public  WebElement clickDocTypeBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(docTypeBtn));
	    	  docTypeBtn.click();
	          
        }catch(Exception e){
            
        }
 	    return docTypeBtn; 
}
   
    public  WebElement clickDocSourceBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(docSourceBtn));
	    	  docSourceBtn.click();
            
         }catch(Exception e){
              
         }
        return docSourceBtn;
}
    public  boolean clickAddBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(addBtn));
	    	  addBtn.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}
    
    public boolean inputFiledDate() {
    	try{
    		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    		LocalDateTime now = LocalDateTime.now();
    		String currentDate=dtf.format(now);
    		System.out.println(currentDate);
		    WebDriverWait wait  = new WebDriverWait(driver,20);
		    wait.until(ExpectedConditions.visibilityOf(filedDate));
		    filedDate.click();
		    filedDate.sendKeys(currentDate);
        return true;
    	}catch(Exception e){
    		e.getStackTrace();
    		return false;
    	}
    }
    
    public boolean inputDescTxt(String text) {
    	
		
    		try{			
    			WebDriverWait wait  = new WebDriverWait(driver,20);
    			wait.until(ExpectedConditions.elementToBeClickable(descTxt));			
    			descTxt.click();
    			descTxt.clear();
    			descTxt.sendKeys(text);
    			return true; 
    		}catch(Exception e){
    			e.printStackTrace();
    			return false; 
    		}
            
        }
        
    public boolean inputDocketNumTxt(String caseName) {
    	
		
    		try{			
    			WebDriverWait wait  = new WebDriverWait(driver,20);
    			wait.until(ExpectedConditions.elementToBeClickable(docketNumTxt));			
    			docketNumTxt.click();
    			docketNumTxt.clear();
    			docketNumTxt.sendKeys(caseName);
    			return true; 
    		}catch(Exception e){
    			e.printStackTrace();
    			return false; 
    		}
            
        }
        
    public boolean inputSearchTxt(String docNum) {
    	
		
		try{			
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(inputdocketNum));			
			inputdocketNum.click();
			inputdocketNum.clear();
			inputdocketNum.sendKeys(docNum);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false; 
		}
        
    }
    
    public  boolean clickSearchBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(searchBtn));
	    	  searchBtn.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}
    
    public  boolean clickDeleteDocBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(deleteDocBtn));
	    	  deleteDocBtn.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}
    
    public  boolean clickUpdateDocBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(updateDocBtn));
	    	  updateDocBtn.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}
    
    public boolean clickEditRecordLink() {
        
    	try{
	       	WebDriverWait wait  = new WebDriverWait(driver,20);
	    	wait.until(ExpectedConditions.elementToBeClickable(editRecordLink));
	    	editRecordLink.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }
    
    public boolean ClickDeleteRecordLink() {
        
    	try{
	       	WebDriverWait wait  = new WebDriverWait(driver,20);
	    	wait.until(ExpectedConditions.elementToBeClickable(deleteRecordLink));
	    	deleteRecordLink.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }
    
    public boolean clickDocProceesingLink() {
        
    	try{
	       	WebDriverWait wait  = new WebDriverWait(driver,20);
	    	wait.until(ExpectedConditions.elementToBeClickable(docProceesingLink));
	    	docProceesingLink.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }
    
    public boolean clickPOClink() {
        
    	try{
	       	WebDriverWait wait  = new WebDriverWait(driver,20);
	    	wait.until(ExpectedConditions.elementToBeClickable(POClink));
	    	POClink.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }
    
    
    public boolean clickInputDocLink() {
        
    	try{
	       	WebDriverWait wait  = new WebDriverWait(driver,20);
	    	wait.until(ExpectedConditions.elementToBeClickable(inputDocLink));
	    	inputDocLink.click();
              return true; 
           }catch(Exception e){
                return false; 
           }
    }
    
    
    public  boolean clickSaveContBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(saveContBtn));
	    	  saveContBtn.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}
    
    
    public  boolean clickSearchMMLBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(searchMMLBtn));
	    	  searchMMLBtn.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
}
    
    public  WebElement clickAddrTypeBtn() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(addrTypeBtn));
	    	  addrTypeBtn.click();
           
         }catch(Exception e){
              e.printStackTrace();
         }
        return addrTypeBtn; 
}   
    public  boolean clickChkBox() {
        try{
	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
	    	  wait.until(ExpectedConditions.elementToBeClickable(ChkBox));
	    	  ChkBox.click();
            return true; 
         }catch(Exception e){
              return false; 
         }
    }   
        public  boolean clickSelMMLRecBtn() {
            try{
    	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
    	    	  wait.until(ExpectedConditions.elementToBeClickable(selMMLRecBtn));
    	    	  selMMLRecBtn.click();
                return true; 
             }catch(Exception e){
                  return false; 
             }
    }
        
        public  boolean clickFlagChkBox() {
            try{
    	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
    	    	  wait.until(ExpectedConditions.elementToBeClickable(FlagChkBox));
    	    	  FlagChkBox.click();
                return true; 
             }catch(Exception e){
                  return false; 
             }
    }
        
        public  boolean clickOKBtn() {
            try{
    	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
    	    	  wait.until(ExpectedConditions.elementToBeClickable(OKBtn));
    	    	  OKBtn.click();
                return true; 
             }catch(Exception e){
                  return false; 
             }
    }
        
        public boolean selectClmfilingDate() {
        	try{
        		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        		LocalDateTime now = LocalDateTime.now();
        		String currentDate=dtf.format(now);
        		System.out.println(currentDate);
    		    WebDriverWait wait  = new WebDriverWait(driver,20);
    		    wait.until(ExpectedConditions.visibilityOf(ClmfilingDate));
    		    ClmfilingDate.click();
    		    ClmfilingDate.sendKeys(currentDate);
            return true;
        	}catch(Exception e){
        		e.getStackTrace();
        		return false;
        	}
        }
        public  boolean clickSaveDoneBtn() {
            try{
    	       	  WebDriverWait wait  = new WebDriverWait(driver,20);
    	    	  wait.until(ExpectedConditions.elementToBeClickable(saveDoneBtn));
    	    	  saveDoneBtn.click();
                return true; 
             }catch(Exception e){
                  return false; 
             }
    }     
        
}    

