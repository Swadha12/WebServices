package com.Pom_PrimeClerk;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.UtilityFiles.CommonUtils;

public class PrimeClerkLoginPage {

	WebDriver driver;

	public PrimeClerkLoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		// PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
		this.driver = driver;   
	}


	/* --------------------------------------------------------
	Prime Clerk Login Page Elements

	----------------------------------------------------------- */

	@FindBy(xpath = "//input[@id='UserName']")
	public WebElement ID;

	@FindBy(xpath = "//input[@id='Password']")
	private WebElement PWD;

	@FindBy(xpath = "//input[@id='btnSubmit']")
	private WebElement LoginBtn;

	@FindBy(xpath = "//a[@title='Logout']")
	private WebElement LogOutBtn;

	/* --------------------------------------------------------
	Prime Clerk Login Page Methods

	----------------------------------------------------------- */


	public boolean  enterID(String userName) {         
		driver=CommonUtils.drv;
		try{			
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(ID));
			ID.click();
			ID.clear();
			ID.sendKeys(userName);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}


	public boolean  enterPwd(String userPwd) {        
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(PWD));
			PWD.click();
			PWD.clear();
			PWD.sendKeys(userPwd);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}


	public  boolean clickLoginBtn () {
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(LoginBtn));
			LoginBtn.click();
			return true; 
		}catch(Exception e){
			return false; 
		}
	}


	public  boolean clickLogOutBtn () {
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(LogOutBtn));
			LogOutBtn.click();
			return true; 
		}catch(Exception e){
			return false;
		}
	}

}


