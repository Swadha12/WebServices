package com.Pom_PrimeClerk;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PrimeClerkManageDocPage {
	
    WebDriver driver;
	
	public PrimeClerkManageDocPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
	       PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
	       this.driver=driver;
      }

	/* --------------------------------------------------------
	prime Clerk Home Page Elements

	----------------------------------------------------------- */
	   @FindBy(xpath="//input[@title='Add Document']")
	   private WebElement AddDocs;

	/* --------------------------------------------------------
	Prime Clerk Home Page Methods
	----------------------------------------------------------- */
   public  boolean clickAddDocBtn() {
       try{
       	 WebDriverWait wait  = new WebDriverWait(driver,20);
    	 wait.until(ExpectedConditions.elementToBeClickable(AddDocs));
 	     AddDocs.click();
         return true; 
        }catch(Exception e){
         return false; 
        }
  }
}