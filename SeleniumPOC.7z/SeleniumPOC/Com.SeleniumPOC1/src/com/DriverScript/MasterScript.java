package com.DriverScript;

import java.io.FileInputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;

import com.TestCases.IPlanNBA.AddCategory;
import com.UtilityFiles.CommonFunctions;
import com.UtilityFiles.ExtentReport;
import com.UtilityFiles.FPath;
import com.UtilityFiles.GenericLibrary;

public class MasterScript {

	public static String GlobalScript;
	public static String ScreenShotPath;
	public static String ExtentReportPath;
	public static String ConstantTimeStamp;
	public static String Logpath;
	public static String sheetName;
	public static String ModuleName;
	public static String TestCaseId;
	public static String RunMode;
	public static String URL;
	public static String Browser;	
	static int TotalPass=0, TotalFail=0, TotalSkip=0;
	public static String scriptName;    
	public static String SourceSystem;
	public static int Counter = 0;
	public static int testscriptcount = 1;

	public static void main(String[] args) throws Exception {
		MasterScript ms=new MasterScript();
		ConstantTimeStamp=GenericLibrary.getTimeStamp();
		ExtentReportPath=GenericLibrary.createExtenReprtFolder();		
		try{
			ExtentReport.classAInstance.startReport(ExtentReportPath);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		ms.RunTestSuite();
	}
	public void RunTestSuite() throws Exception 
	{
		long SuiteStop=0;
		long SuiteDuration=0;
		String Duration="";

		try{
			//ConstantTimeStamp=GenericLibrary.getTimeStamp();
			String ResDir =  GenericLibrary.createResultFolder();
			GenericLibrary.createLogFolder();
			ScreenShotPath=GenericLibrary.createScreenShotFolder();
			
			GenericLibrary.copyFile();
			long SuiteStart = new Date().getTime();// Start Time for entire suite
			//Reading Configuration Excel
			FileInputStream fileInputStream = new FileInputStream(FPath.CONFIGURATION);
			Workbook wb = WorkbookFactory.create(fileInputStream);
			Sheet config = wb.getSheetAt(0);
			for (int p= 1; p<=config.getLastRowNum();p++)
			{
				org.apache.poi.ss.usermodel.Row row = config.getRow(p);
				org.apache.poi.ss.usermodel.Cell name = row.getCell(0);
				org.apache.poi.ss.usermodel.Cell value = row.getCell(1);
				org.apache.poi.ss.usermodel.Cell execute = row.getCell(2);
				String Name = name.getRichStringCellValue().toString();
				String Value = value.getRichStringCellValue().toString();
				String Execute = execute.getRichStringCellValue().toString();
				if(Name.equalsIgnoreCase("Browser")&& Execute.equalsIgnoreCase("Yes")){
					Browser = Value;
				}else if(Name.equalsIgnoreCase("Application_URL")&& Execute.equalsIgnoreCase("Yes")){
					URL = Value;
				}
				
				
			}
			
			
			
			Sheet module = wb.getSheetAt(1);
			int rowCnt = module.getLastRowNum();
			GlobalScript=FPath.LOGS+MasterScript.ConstantTimeStamp+"/"+"mytest02"+".xlsx";
			GenericLibrary.Create_LogFile("mytest02");//point 1
			
			for(int j=1;j<=rowCnt;j++){
				Counter=0;
				org.apache.poi.ss.usermodel.Row row = module.getRow(j);
				org.apache.poi.ss.usermodel.Cell cell = row.getCell(1);                                                              
				String execStatus = cell.getRichStringCellValue().toString();				
				if(execStatus.equalsIgnoreCase("yes")){					
					org.apache.poi.ss.usermodel.Cell cell1 = row.getCell(0);
					ModuleName=cell1.getRichStringCellValue().toString();					
					int indexNo=ModuleName.lastIndexOf(".")+1;
					sheetName=ModuleName.substring(indexNo);					
					Sheet testCase = wb.getSheet(sheetName);
					
					
					int lastrow = testCase.getLastRowNum();
					
					List <String> testId = new ArrayList<String>();
					
				   // String testId[]=new String[lastrow];
				    System.out.println(lastrow + " lastrow ");
				    
				    for (int p = 1; p <= lastrow; p++) {				    	
				    	    TestCaseId= testCase.getRow(p).getCell(1).toString();
				            RunMode = testCase.getRow(p).getCell(2).toString();				            
				            if(RunMode.equalsIgnoreCase("YES")){
				            	testId.add(TestCaseId);
				            }
				     }					
					
						for(String id:testId ){
						scriptName=id;
						System.out.println(scriptName);					
						//GlobalScript=FPath.LOGS+MasterScript.ConstantTimeStamp+"/"+"mytest02"+".xlsx";
						Class<?> c;
						try{
							ExtentReport.classAInstance.StartTest(scriptName);
						}catch(Exception e){
							e.printStackTrace();
						}
						long startTime = new Date().getTime();
						c = Class.forName(ModuleName); // ClassName
						java.lang.reflect.Constructor<?> cons = c.getConstructor();
						Object object = cons.newInstance();
						java.lang.reflect.Method method= object.getClass().getMethod(scriptName);              
						//java.lang.reflect.Method method= c.getMethod(className);
						Boolean bool =  (Boolean) method.invoke(object);
						//end Extent report
						ExtentReport.classAInstance.endReport();              
						long stopTime = new Date().getTime(); // Stop Time for a individual test
						//Casting of object to boolean
						boolean b = Boolean.valueOf(bool.toString());
						SuiteStop = new Date().getTime(); // End Time for entire suite
						SuiteDuration = (SuiteStop-SuiteStart)/ 1000;
						Duration= GenericLibrary.getTime(SuiteDuration);
						Counter = Counter+2;
						if (b==false) //To Check complete test case Pass/Fail
						{
							GenericLibrary.setResultCell(scriptName,"Pass"); 
							GenericLibrary.CreateHTMLReport(Duration, ConstantTimeStamp, ConstantTimeStamp);
						}
						else
						{
							GenericLibrary.setResultCell(scriptName, "Fail");
							GenericLibrary.CreateHTMLReport(Duration, ConstantTimeStamp, ConstantTimeStamp);
						}
					
						
						testscriptcount = testscriptcount+1;
						
						
						
						}

				}
			}
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}      
	}

}


