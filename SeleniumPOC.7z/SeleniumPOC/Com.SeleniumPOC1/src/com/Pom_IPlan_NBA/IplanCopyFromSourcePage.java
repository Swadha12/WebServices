package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IplanCopyFromSourcePage {
	
	WebDriver driver;
	
	public IplanCopyFromSourcePage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
	       PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
	       this.driver=driver;
      }
	
	/* --------------------------------------------------------
	NBA Iplan copy from source Page Elements

	----------------------------------------------------------- */
		
    @FindBy(xpath = "//select[contains(@id,'ddlSeason')]")
    private WebElement Seasonlist;
    
    @FindBy(xpath = "//select[contains(@id,'ddlIplanName')]")
    private WebElement iplanname;
    
	@FindBy(xpath = "//input[contains(@id,'IPlan_btnOk')]")
    private WebElement IplanCopyOKBtn;
    
	/* --------------------------------------------------------
	NBA Iplan copy from source Page Methods

	----------------------------------------------------------- */
	
    public boolean selectSeason(String SeasonName) {
    	
    	  WebDriverWait wait  = new WebDriverWait(driver,20);
		  wait.until(ExpectedConditions.visibilityOf(Seasonlist));
          Select season=new Select(Seasonlist);
          try{
           season.selectByVisibleText(SeasonName);
          }catch(Exception e){
        	  return false; 
           }
          return true;
    }
    
    
    
    public boolean slelectPlan(String IplanName) {
      
          try{
        	  WebDriverWait wait  = new WebDriverWait(driver,20);
    		  wait.until(ExpectedConditions.visibilityOf(iplanname));
    		  Select season=new Select(iplanname);
              season.selectByVisibleText(IplanName);
          }catch(Exception e){
        	  return false;
           }
          return true;
    }
    

	public  boolean clickOkBtn () {
		try{
      	  WebDriverWait wait  = new WebDriverWait(driver,20);
  		  wait.until(ExpectedConditions.elementToBeClickable(IplanCopyOKBtn));		
		  IplanCopyOKBtn.click();
		  return true; 
		}catch(Exception e){
			return false; 
		}
	} 
    
    
    
   

}
