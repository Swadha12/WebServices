package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IplanCopyFromSrcEditPlanPage {
	
	WebDriver driver;
	
	public IplanCopyFromSrcEditPlanPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
		this.driver = driver;
      }
	
	
	/* --------------------------------------------------------
	NBA Iplan copy from source edit page Elements

	----------------------------------------------------------- */
	
    @FindBy(xpath = "//select[contains(@id,'IPlanView_ddlSeason')]")
    private WebElement iplancopyseasonlist;
    
    
	@FindBy(xpath = "//input[contains(@id,'IPlanView_txtIPlanName')]")
    private WebElement IplanCopyNameEdit;
	
    @FindBy(xpath = "//input[contains(@id,'cphIPlan_IPlanView_btnSave')]")
    private WebElement IplanCopyNextBtn;
	
    
	/* --------------------------------------------------------
	NBA Iplan copy from source edit page Methods

	----------------------------------------------------------- */  
    
   
    public boolean iplanCopyEditSeason(String IplanCopySeason) {
          
          try{        	  
          	WebDriverWait wait  = new WebDriverWait(driver,20);
      		wait.until(ExpectedConditions.elementToBeClickable(iplancopyseasonlist));
      		Select season=new Select(iplancopyseasonlist);
           season.selectByVisibleText(IplanCopySeason);
          }catch(Exception e){
        	  return false; 
           }
          return true;
    }
    
    
	public boolean enterPreferredPlanName(String PlanName)
	{                 
		try{
			IplanCopyNameEdit.click();
			IplanCopyNameEdit.clear();
			Thread.sleep(2000);
			IplanCopyNameEdit.sendKeys(PlanName);
			return true;			
		}catch(Exception e){
			e.printStackTrace();
			return false; 
		}

	}

    
    
    public boolean iplanCopyNextBtn()
    {                 
		try{
			IplanCopyNextBtn.click();			
			Thread.sleep(2000);						
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		return true;
          
    }
  

}

