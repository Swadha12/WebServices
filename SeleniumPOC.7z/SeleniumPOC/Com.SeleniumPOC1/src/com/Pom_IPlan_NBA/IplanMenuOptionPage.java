package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IplanMenuOptionPage {
	WebDriver driver;
	public IplanMenuOptionPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
		   PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
		   this.driver = driver;
      }
	
	/* --------------------------------------------------------
	NBA Iplan Category Menu Page Elements

	----------------------------------------------------------- */
      
      @FindBy(xpath = "//a[text()='Manage Category']")
      private WebElement ManageCatLink;
      
      @FindBy(xpath = "//a[text()='Copy I-Plan']")
      private WebElement CopyIPlanLink;
      
      @FindBy(xpath = "//a[text()='Manage Media']")
      private WebElement ManageMediaLink;
      
  	/* --------------------------------------------------------
  	NBA Iplan Category Menu Page Methods

  	----------------------------------------------------------- */  
      public  boolean clickMangCatLink () {
  		try{
      	  
        	WebDriverWait wait  = new WebDriverWait(driver,20);
    		wait.until(ExpectedConditions.elementToBeClickable(ManageCatLink));
  			ManageCatLink.click();
  			return true; 
  		}catch(Exception e){
  			return false; 
  		}
       }
      
      
      
      public  boolean clickcopyIPlanLink() {
  		try{
  			CopyIPlanLink.click();
  			return true; 
  		}catch(Exception e){
  			return false; 
  		}
       }
      


}

