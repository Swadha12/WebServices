package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IplanCopyDetailsPage {
	WebDriver driver;
	public IplanCopyDetailsPage(WebDriver driver) {
       // PageFactory.initElements(driver, this);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
		this.driver = driver;
      }
	
	
	
	@FindBy(xpath = "//input[@value='Save For Later']")
    private WebElement CopyplandetailsSubmit;
    
    public boolean iplanCopyPlnDtlSubmitBtn()
    {                 
          try{
        	  
        	  WebDriverWait wait  = new WebDriverWait(driver,20);
  			  wait.until(ExpectedConditions.elementToBeClickable(CopyplandetailsSubmit));
        	  CopyplandetailsSubmit.click(); 
        	  return true;
          }catch(Exception e){
  			return false; 
  		}
		
          
    }
	
	

}
