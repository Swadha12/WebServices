package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IPlanSearchPage {
	
	WebDriver driver;
	
	public IPlanSearchPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
		   PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
		   this.driver = driver;
      }
	
	
	
	@FindBy(xpath = "//input[contains(@id,'cphIPlan_txtIPlanName')]")
    private WebElement IplanSearchName;
    
    public WebElement iplanSearchName()
    {                 
          return IplanSearchName;
          
    }

	@FindBy(xpath = "//a[contains(@id,'lnkIPlanName')]")
    private WebElement PlanName;
    
    public WebElement getPlanName()
    
      {  
    	

    	WebDriverWait wait  = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.elementToBeClickable(PlanName));
          return PlanName;
          
    }

	

}
