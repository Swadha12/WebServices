package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.UtilityFiles.CommonUtils;
import com.UtilityFiles.Constants;

public class IplanCategoryPage {
	WebDriver driver;
	
	
	
	public IplanCategoryPage(WebDriver driver) throws InterruptedException {

		//PageFactory.initElements(driver, this);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
		this.driver = driver;
	}

	/* --------------------------------------------------------
	NBA Iplan Category Page Elements

	----------------------------------------------------------- */

	@FindBy(xpath = "//div[contains(@id,'pnlCategoryHeader')]//span")
	private WebElement clickToAddCat;
	
	
	@FindBy(xpath = "//input[contains(@id,'ctl02_ImageButton2')]")
	private WebElement deletCat;
	
	@FindBy(xpath = "//input[contains(@id,'txtNewCategory')]")
	private WebElement AddNewCatTextBox;
	
	@FindBy(xpath = "//input[@value='Save']")
	private WebElement saveCategory;
	
	@FindBy(xpath = "//input[contains(@id,'txtCategory')]")
	private WebElement searchCatNameTxtBx;
	
	@FindBy(xpath = "//input[contains(@id,'btnSearch')]")
	private WebElement searchCatBtn;
	
	@FindBy(xpath = "//span[contains(@id,'lblEditCategory')]")
	private WebElement catName;
	
	@FindBy(xpath = "//input[contains(@src,'AdminEdit')]")
	private WebElement updateCatButton;
	
	@FindBy(xpath = "//input[contains(@id,'txtEditCategory')]")
	private WebElement updateCatText;
	
	@FindBy(xpath = "//span[@disabled='disabled']/input")
	private WebElement inactiveStatus;
	
	@FindBy(xpath = "//input[@value='Update']")
	private WebElement updateBtn;
	
	@FindBy(xpath = "(//input[@checked='checked'])[1]")
	private WebElement statusActiveCheckbx;
	
	@FindBy(xpath = "//span[contains(@id,'lblErrorMsg')]")
	private WebElement errorCatExist;
	
	@FindBy(xpath = "//input[contains(@id,'ImageButton2')]")
	private WebElement deleteCat;
	
	//span[contains(@id,'lblNumberofRecordsBottom')]
	
	@FindBy(xpath = "//span[contains(@id,'lblNumberofRecordsBottom')]")
	private WebElement numberofRecord;
	
	
	/* --------------------------------------------------------
	NBA Iplan Category Page Methods

	----------------------------------------------------------- */
	
	public boolean clickAddNewCatBtn()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(clickToAddCat));
			clickToAddCat.click();
			return true;
		}catch(Exception e){
			return false; 
		}

	}
	
	public boolean enterNewCatName(String CateName)
	{                 
		try{			
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(AddNewCatTextBox));			
			AddNewCatTextBox.click();
			AddNewCatTextBox.clear();
			AddNewCatTextBox.sendKeys(CateName);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false; 
		}

	}
	
	
	public boolean clickSaveCateBtn()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(saveCategory));
			saveCategory.click();
			return true; 
		}catch(Exception e){
			return false; 
		}

	}
	
	public boolean clickDeletCatBtn()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(deleteCat));
			deleteCat.click();			
			return true; 
		}catch(Exception e){
			return false;
		}

	}
	

	public boolean searchCategoryTxtBox(String CateName)
	{                 
		try{	

			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(searchCatNameTxtBx));
			searchCatNameTxtBx.click();
			searchCatNameTxtBx.clear();
			searchCatNameTxtBx.sendKeys(CateName);
			return true; 
		}catch(Exception e){
			return false; 
		}

	}
	
	
	public boolean updateCatName(String CateName)
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(updateCatText));
			updateCatText.click();
			updateCatText.clear();
			updateCatText.sendKeys(CateName);
			return true; 
		}catch(Exception e){
			return false; 
		}
	}
	

	public boolean clickSearcBtton()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(searchCatBtn));
			searchCatBtn.click();
			return true; 
		}catch(Exception e){
			return false; 
		}

	}

	public String getCateName()
	{                 
		try{

			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(catName));
			String CategoryName = catName.getText();
			return CategoryName; 
		}catch(Exception e){
			return null; 
		}

	}
	
	
	public String getCatRecords()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.visibilityOf(numberofRecord));
			String CategoryName = numberofRecord.getText();
			return CategoryName; 
		}catch(Exception e){
			return null; 
		}

	}
	
	public String getExistCatError()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.visibilityOf(errorCatExist));
			String ErrCategoryNameExist = errorCatExist.getText();
			return ErrCategoryNameExist; 
		}catch(Exception e){
			return null; 
		}

	}
	
	
	public boolean clickUpdateCategoryBtn()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(updateCatButton));
			updateCatButton.click();
			return true; 
		}catch(Exception e){
			return false;
		}
	}
	
	
	public boolean selectChkBoxtToInactive()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.visibilityOf(statusActiveCheckbx));
			statusActiveCheckbx.click();
			return true; 
		}catch(Exception e){
			return false;
		}

	}
	
	public boolean clickUpdateBtn()
	{                 
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(updateBtn));		
			updateBtn.click();
			return true; 
		}catch(Exception e){
			return false;
		}

	}
	
	public String getcheckBoxStatusDisabled()
	{                 
		try{

			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(inactiveStatus));			
			String status = inactiveStatus.getAttribute("checked");
			if(status != null){
			return "Enabled";
			}else{
		    return "Disabled";	
		    }
		}catch(Exception e){
			return "Disabled";
		}

	}


	

}

