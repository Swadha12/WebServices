package com.Pom_IPlan_NBA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IplanLoginPage {
	
	WebDriver driver;

	public IplanLoginPage(WebDriver driver) {
		// PageFactory.initElements(driver, this);
	       PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
	       this.driver = driver;

	}

	/* --------------------------------------------------------
	NBA Iplan Login Page Elements

	----------------------------------------------------------- */
	
	@FindBy(xpath = "//select[contains(@id,'cphIPlan_ddlUser')]")
	private WebElement list;

	@FindBy(xpath = "//input[@value='Logout']")
	private WebElement LogOutBtn;

	@FindBy(xpath = "//input[contains(@id,'_cphIPlan_btnLogin')]")
	private WebElement LoginBtn;


	/* --------------------------------------------------------
	NBA Iplan Login Page Methods

	----------------------------------------------------------- */
	
	
	public boolean selectProfile(String profile) {
				
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(list));
			Select stat=new Select(list);
			stat.selectByVisibleText(profile);
		}catch(Exception e){
			return false; 
		}
		return true;
	}



	public  boolean clickLoginBtn () {
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(LoginBtn));
			LoginBtn.click();
			return true; 
		}catch(Exception e){
			return false; 
		}
	}


	public  boolean clickLogoutBtn () {
		try{
			WebDriverWait wait  = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(LogOutBtn));
			LogOutBtn.click();
			return true; 
		}catch(Exception e){
			return false; 
		}

	}
}

