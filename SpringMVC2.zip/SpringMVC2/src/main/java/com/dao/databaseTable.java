package com.dao;

public class databaseTable {
/* create schema name as test in mySQL then create below table
	CREATE TABLE 'users' ('user_id' int(11) not NULL AUTO_INCREAMENT,
			              'user_name' varchar(25) DEFAULT NULL,
			              'email' varchar(45) NOT NULL, PRIMARY KEY('user_id'))

*/
	}

