package com.test;

import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import java.io.FileInputStream;
import java.io.StringWriter;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SoapRequest {
private SOAPConnectionFactory soapConnectionFactory;
private SOAPConnection soapConnection ;
private MessageFactory messageFactory;
private SOAPMessage soapMessage;
private SOAPPart soapPart;

@Before
public void setUp(){

try {
//creating connection object

soapConnectionFactory = SOAPConnectionFactory.newInstance();
soapConnection = soapConnectionFactory.createConnection();

//creating message object
messageFactory = MessageFactory.newInstance();
soapMessage = messageFactory.createMessage();
soapPart = soapMessage.getSOAPPart();
} catch (UnsupportedOperationException e) {
// TODO Auto-generated catch block
 e.printStackTrace();
} catch (SOAPException Ex){
	// TODO Auto-generated catch block
	Ex.getStackTrace();
}
}

@Test
public void testSOAPRequest(){
 System.out.println("123");
	try {
		FileInputStream fis = new FileInputStream("D://SeleniumAutomation//GoogleWeather//Data1.txt");
// Object for message parts
StreamSource prepMsg = new StreamSource(fis);
soapPart.setContent(prepMsg);

// Save message
soapMessage.saveChanges();

//change header's attribute
MimeHeaders mimeHeader = soapMessage.getMimeHeaders();
mimeHeader.setHeader("SOAPAction", "http://www.webserviceX.NET/ConversionRate");

// Send request to url
String endPoinUrl = "http://www.webservicex.com/CurrencyConvertor.asmx";
SOAPMessage messagerequest = soapConnection.call(soapMessage, endPoinUrl);

// response data
Source source = messagerequest.getSOAPPart().getContent();
// Create transformer object
TransformerFactory transformerFactory = TransformerFactory.newInstance();
Transformer transformer = transformerFactory.newTransformer();

// set response parameter to string
StringWriter writer = new StringWriter();
StreamResult sResult = new StreamResult(writer);
transformer.transform(source, sResult);
String result1 = writer.toString();
System.out.println(result1);
//Thread.sleep(10000);
System.out.println(result1.contains("103.935"));
Assert.assertTrue(result1.contains("103.935"));
System.out.println(result1);

// close connection
soapConnection.close();

} catch (Exception e) {
    System.out.println(e.getMessage());
    
   }
/*
@After
  {
	  System.out.println("execution completed");
  }
 */ 
}


}
