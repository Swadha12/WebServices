package test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTabbedPane;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Resturant {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Resturant window = new Resturant();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Resturant() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1368, 689);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(22, 525, -4, 60);
		frame.getContentPane().add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_3.setBounds(37, 580, 1281, 60);
		frame.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Total");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(210, 11, 89, 23);
		panel_3.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Reciept");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_2.setBounds(348, 11, 89, 23);
		panel_3.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Reset");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_4.setText(null);
				textField_5.setText(null);
				textField_3.setText(null);
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_3.setBounds(486, 11, 89, 23);
		panel_3.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Exit");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_4.setBounds(611, 11, 89, 23);
		panel_3.add(btnNewButton_4);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_4.setBounds(1134, 102, 181, 467);
		frame.getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(71, 13, 5, 5);
		panel_4.add(tabbedPane);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(10, 29, 161, 427);
		panel_4.add(tabbedPane_1);
		
		JPanel panel = new JPanel();
		tabbedPane_1.addTab("Reciept", null, panel, null);
		panel.setLayout(null);
		
		textField_3 = new JTextField();
		textField_3.setBounds(10, 0, 146, 388);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JPanel panel_8 = new JPanel();
		tabbedPane_1.addTab("Calculator", null, panel_8, null);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_5.setBounds(919, 427, 242, 142);
		frame.getContentPane().add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblTax = new JLabel("Tax");
		lblTax.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblTax.setBounds(20, 11, 77, 27);
		panel_5.add(lblTax);
		
		JLabel lblSubTotal = new JLabel("Sub Total");
		lblSubTotal.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblSubTotal.setBounds(20, 49, 88, 27);
		panel_5.add(lblSubTotal);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblTotal.setBounds(20, 85, 77, 27);
		panel_5.add(lblTotal);
		
		JLabel label_3 = new JLabel("");
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_3.setBounds(135, 11, 77, 27);
		panel_5.add(label_3);
		
		JLabel label_4 = new JLabel("");
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_4.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_4.setBounds(135, 49, 77, 27);
		panel_5.add(label_4);
		
		JLabel label_5 = new JLabel("");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_5.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_5.setBounds(135, 85, 77, 27);
		panel_5.add(label_5);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_6.setBounds(919, 102, 205, 314);
		frame.getContentPane().add(panel_6);
		panel_6.setLayout(null);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Choose One Option", "India", "Pak", "Japan", "Auatralia", "USA", "England"}));
		comboBox_1.setBounds(26, 55, 141, 28);
		panel_6.add(comboBox_1);
		
		textField_5 = new JTextField();
		textField_5.setBounds(26, 94, 141, 20);
		textField_5.setColumns(10);
		panel_6.add(textField_5);
		
		JLabel label_8 = new JLabel("");
		label_8.setBounds(26, 128, 142, 31);
		label_8.setHorizontalAlignment(SwingConstants.RIGHT);
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_8.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_6.add(label_8);
		
		JButton btnNewButton = new JButton("Convert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(26, 216, 71, 31);
		panel_6.add(btnNewButton);
		
		JButton btnClose = new JButton("Close");
		btnClose.setBounds(106, 216, 71, 31);
		panel_6.add(btnClose);
		
		JLabel lblNewLabel_2 = new JLabel("Corency Converter");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(26, 11, 141, 33);
		panel_6.add(lblNewLabel_2);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_7.setBounds(37, 427, 872, 142);
		frame.getContentPane().add(panel_7);
		panel_7.setLayout(null);
		
		JLabel lblCostOfDrinks = new JLabel("Cost of Drinks");
		lblCostOfDrinks.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblCostOfDrinks.setBounds(21, 22, 176, 31);
		panel_7.add(lblCostOfDrinks);
		
		JLabel lblCostOf = new JLabel("Cost of Meal ");
		lblCostOf.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblCostOf.setBounds(21, 58, 235, 31);
		panel_7.add(lblCostOf);
		
		JLabel lblCostOfDelivery = new JLabel("Cost of Delivery");
		lblCostOfDelivery.setFont(new Font("Tahoma", Font.PLAIN, 23));
		lblCostOfDelivery.setBounds(21, 87, 176, 31);
		panel_7.add(lblCostOfDelivery);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(509, 21, 159, 31);
		lblNewLabel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_7.add(lblNewLabel_1);
		
		JLabel label_6 = new JLabel("");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_6.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_6.setBounds(509, 58, 159, 31);
		panel_7.add(label_6);
		
		JLabel label_7 = new JLabel("");
		label_7.setHorizontalAlignment(SwingConstants.RIGHT);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 24));
		label_7.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		label_7.setBounds(509, 100, 159, 31);
		panel_7.add(label_7);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		panel_1.setBounds(37, 102, 872, 314);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblChickenBurger = new JLabel("Chicken Burger ");
		lblChickenBurger.setBounds(26, 27, 176, 31);
		lblChickenBurger.setFont(new Font("Tahoma", Font.PLAIN, 23));
		panel_1.add(lblChickenBurger);
		
		JLabel label = new JLabel("");
		label.setBounds(36, 60, 46, 14);
		panel_1.add(label);
		
		JLabel label_1 = new JLabel("Chicken Burger Meal");
		label_1.setBounds(26, 63, 235, 31);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 23));
		panel_1.add(label_1);
		
		JLabel label_2 = new JLabel("Cheese Burger");
		label_2.setBounds(26, 92, 176, 31);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 23));
		panel_1.add(label_2);
		
		textField = new JTextField();
		textField.setBounds(409, 27, 161, 20);
		panel_1.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(409, 60, 161, 20);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(409, 92, 161, 20);
		panel_1.add(textField_2);
		textField_2.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select a drink", "Tea", "Coffee", "Coke", "Juice", "Shake"}));
		comboBox.setBounds(26, 189, 141, 20);
		panel_1.add(comboBox);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Home Delivery");
		chckbxNewCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 16));
		chckbxNewCheckBox.setBounds(25, 244, 142, 23);
		panel_1.add(chckbxNewCheckBox);
		
		JCheckBox chckbxTax = new JCheckBox("Tax");
		chckbxTax.setFont(new Font("Tahoma", Font.PLAIN, 16));
		chckbxTax.setBounds(419, 244, 142, 23);
		panel_1.add(chckbxTax);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(409, 189, 161, 20);
		panel_1.add(textField_4);
		
		JLabel lblDrink = new JLabel("Drink");
		lblDrink.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblDrink.setBounds(26, 147, 176, 31);
		panel_1.add(lblDrink);
		
		JLabel lblQty = new JLabel("Qty");
		lblQty.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblQty.setBounds(409, 147, 176, 31);
		panel_1.add(lblQty);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(26, 141, 544, 2);
		panel_1.add(separator);
		
		JLabel lblNewLabel = new JLabel("Loan Management Systems");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 80));
		lblNewLabel.setBounds(122, 0, 1151, 91);
		frame.getContentPane().add(lblNewLabel);
	}
}
