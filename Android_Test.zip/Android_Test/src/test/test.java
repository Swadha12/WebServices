package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;

public class test {
	public static String toHex(String args){
	//System.out.println("octal number of name is-" +String.format("%x", new BigInteger(args.getBytes())));
	return String.format("%x", new BigInteger(args.getBytes()));
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
System.out.println("okay");
String fileName="C:\\Users\\stripathi\\Desktop\\data.csv";
File file=new File(fileName);
Scanner inputStream= new Scanner(file);
inputStream.next(); //to ignore header value
int decimal=56;
System.out.println("octal number of decimal number is-" +Integer.toOctalString(decimal));
String name="swadha,tripathi,bnagalore,31,88"+
"Amit,Shukla,pune,30,89"+
"shashi,tripathi,ald,33,77"+
"sunil,tiwari,ald,33,85"+
"manjula,tripathi,noida,35,87"+
"vivek,tripathi,ghaziabad,37,79";
String value = toHex(name);
System.out.println(value);

int sum=0;
int numOfPrices=0;
// to read any specific colum and do operation
while(inputStream.hasNext()){
	String data=inputStream.next();
	System.out.println(data);
	String[] values = data.split(",");
	double closingPricess = Double.parseDouble(values[4]);
	sum+=closingPricess;
	numOfPrices++;
   // System.out.println("\n");
}
System.out.println("total of all the marks : "+sum);
System.out.println("avarage is - " +sum/numOfPrices);

//System.out.println("\n");
	

inputStream.close();
	}

}
