package test;

import java.io.File;
import java.math.BigInteger;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

public class OpenFile {

	public static final StringBuffer  sb=new StringBuffer();

	public void PickMe() {
		// TODO Auto-generated method stub
		final JFileChooser fc=new  JFileChooser();
		
		try{
		FileFilter filter=new FileNameExtensionFilter("CSV File","csv");
		fc.setFileFilter(filter);
		if(fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
			File file=fc.getSelectedFile();
			Scanner inputStream= new Scanner(file); 
			
			while(inputStream.hasNext()){
				String data=inputStream.next();
				sb.append(data);
				sb.append("\n");
				
			}
			inputStream.close();
    	}else{
    		sb.append("no file selected");
    	}
		
	}catch(Exception e){
    		{
    			e.getStackTrace();
    		}
		
		
    	
		}
		
		}
	
}
