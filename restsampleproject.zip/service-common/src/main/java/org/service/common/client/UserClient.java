package org.service.common.client;

import org.service.common.entity.Address;
import org.service.common.entity.UserBean;
import org.springframework.stereotype.Service;

@Service("userClient")
public class UserClient implements IUserClient {

	public UserBean getUser() {
		UserBean userbean = new UserBean();
		Address address = new Address();
		address.setAddressId(546);
		address.setAddressLine1("White field");
		address.setAddressType("permanent");
		address.setCity("Bangalore");
		address.setEmail("xyz@galaxe.com");
		address.setPhone("08041429192");
		address.setState("KA");
		address.setZip("560037");

		userbean.getAddresses().add(address);
		userbean.setFirstName("Firstname");
		userbean.setLastName("lastname");
		userbean.setUserId(439857);

		return userbean;
	}

}
