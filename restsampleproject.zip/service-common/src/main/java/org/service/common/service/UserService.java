package org.service.common.service;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.service.common.client.IUserClient;
import org.service.common.entity.UserBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("userservice")
@Path("/userservice")
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class UserService implements IUserService{

	@Autowired
	IUserClient userClient;
	
	@POST
	@Path("/adduser")
	public UserBean addUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@GET
	@Path("/getuser")
	public UserBean getUser() {
		UserBean userbean = userClient.getUser();
		return userbean;
	}

	@PUT
	@Path("/updateuser")
	public UserBean updateUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@DELETE
	@Path("/deleteuser")
	public String deleteUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@GET
	@Path("/loadusers")
	public List<UserBean> loadUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
