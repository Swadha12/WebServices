package org.service.common.client;

import org.service.common.entity.UserBean;

public interface IUserClient {

	public UserBean getUser();
}
