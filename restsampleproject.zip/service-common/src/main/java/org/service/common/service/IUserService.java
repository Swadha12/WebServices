package org.service.common.service;

import java.util.List;

import org.service.common.entity.UserBean;

public interface IUserService {

	public UserBean addUser();
	public UserBean getUser();
	public UserBean updateUser();
	public String deleteUser();
	public List<UserBean> loadUsers();
}
