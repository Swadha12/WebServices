package assignment1;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	Connection connection=null;
	private JTextField textFieldUsername;
	private JPasswordField passwordField;
	public Login() {
		initialize();
		connection=SqliteConnection.dbConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 12));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textFieldUsername = new JTextField();
		textFieldUsername.setBounds(231, 48, 86, 20);
		frame.getContentPane().add(textFieldUsername);
		textFieldUsername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(67, 51, 65, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(67, 121, 6, -14);
		frame.getContentPane().add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(231, 87, 86, 20);
		frame.getContentPane().add(passwordField);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPassword.setBounds(67, 90, 65, 14);
		frame.getContentPane().add(lblPassword);
		
		JButton btnLogin = new JButton("Login");
		//Image img1 = new ImageIcon(this.getClass().getResource("/ok.png").getFile());
		//btnLogin.setIcon(new ImageIcon());
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
			String query="select * from EmployeeInfo where username=? and password=?";
			PreparedStatement pst = connection.prepareStatement(query);
			pst.setString(1,textFieldUsername.getText() );
			pst.setString(2,passwordField.getText() );
			ResultSet rs = pst.executeQuery();
			int count=0;
			while(rs.next()){
				count=count+1;
			}
			if(count==1){
				JOptionPane.showMessageDialog(null,"Username and Password is correct");
				frame.dispose();
				EmployeeInfo emplInfo = new EmployeeInfo();
				emplInfo.setVisible(true);
			}
			else if(count>1){
				JOptionPane.showMessageDialog(null,"Duplicate Username and Password");
			}
			else{
				JOptionPane.showMessageDialog(null,"invalid Username and Password Try Again....");
			}
		//	rs.close();
		//	pst.close();
				} catch (SQLException e) {
				// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null,e);
			}
			
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnLogin.setBounds(140, 152, 89, 23);
		frame.getContentPane().add(btnLogin);
	}
}
