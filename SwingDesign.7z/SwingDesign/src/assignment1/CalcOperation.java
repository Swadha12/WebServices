package assignment1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class CalcOperation {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalcOperation window = new CalcOperation();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CalcOperation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(43, 47, 125, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(197, 47, 131, 28);
		textField_1.setColumns(10);
		frame.getContentPane().add(textField_1);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1,num2,add;
				try{
					num1=Integer.parseInt(textField.getText());
					num2=Integer.parseInt(textField_1.getText());
					add= num1+num2;
					textField_2.setText(Integer.toString(add));	
				}catch(Exception ex){
					JOptionPane.showMessageDialog(null,"Please enter numeric values");
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(43, 126, 125, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnMinus = new JButton("Minus");
		btnMinus.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnMinus.setBounds(215, 126, 125, 23);
		btnMinus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1,num2,add;
				try{
					num1=Integer.parseInt(textField.getText());
					num2=Integer.parseInt(textField_1.getText());
					add= num1-num2;
					textField_2.setText(Integer.toString(add));	
				}catch(Exception ex){
					JOptionPane.showMessageDialog(null,"Please enter numeric values");
				}

			}
		});
		frame.getContentPane().add(btnMinus);
		
		JLabel lblAnsIs = new JLabel("Ans Is = ");
		lblAnsIs.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAnsIs.setBounds(86, 187, 72, 28);
		frame.getContentPane().add(lblAnsIs);
		
		textField_2 = new JTextField();
		textField_2.setBounds(182, 191, 86, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
	}
}
